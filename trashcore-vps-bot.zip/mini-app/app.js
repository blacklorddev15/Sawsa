(() => {
  'use strict';

  const telegram = window.Telegram && window.Telegram.WebApp;
  const byId = id => document.getElementById(id);
  const panelUrl = 'https://panel.drextrash.online/';
  const statusNode = byId('request-status');
  const refreshButton = byId('refresh-data');
  const menu = byId('nav-menu');
  let dashboard = null;
  let receivedAt = 0;
  let refreshTimer = null;

  if (telegram) {
    telegram.ready();
    if (typeof telegram.expand === 'function') telegram.expand();
    if (typeof telegram.setHeaderColor === 'function') telegram.setHeaderColor('#080d0d');
    if (typeof telegram.setBackgroundColor === 'function') telegram.setBackgroundColor('#080d0d');
  }

  function setText(id, value) {
    const element = byId(id);
    if (element) element.textContent = value == null || value === '' ? '—' : String(value);
  }

  function formatBytes(value) {
    if (value === null || value === undefined || value === '') return null;
    const bytes = Number(value);
    if (!Number.isFinite(bytes) || bytes < 0) return null;
    const gib = bytes / (1024 ** 3);
    return `${Number.isInteger(gib) ? gib : gib.toFixed(1)} GiB RAM`;
  }

  function formatDuration(value) {
    if (value === null || value === undefined || value === '') return null;
    const seconds = Number(value);
    if (!Number.isFinite(seconds) || seconds < 0) return null;
    let remaining = Math.floor(seconds);
    const days = Math.floor(remaining / 86400);
    remaining %= 86400;
    const hours = Math.floor(remaining / 3600);
    remaining %= 3600;
    const minutes = Math.floor(remaining / 60);
    const parts = [];
    if (days) parts.push(`${days}d`);
    if (hours || days) parts.push(`${hours}h`);
    parts.push(`${minutes}m`);
    return parts.join(' ');
  }

  function updateClock() {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('en-KE', {
      timeZone: 'Africa/Nairobi', weekday: 'short', day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
    });
    const element = byId('clock');
    if (element) {
      element.dateTime = now.toISOString();
      element.textContent = `${formatter.format(now)} EAT`;
    }
    if (dashboard && receivedAt) {
      const elapsed = Math.max(0, Math.floor((Date.now() - receivedAt) / 1000));
      const updated = new Date(dashboard.updatedAt || now);
      const updatedElement = byId('updated-at');
      if (updatedElement) {
        updatedElement.dateTime = updated.toISOString();
        updatedElement.textContent = new Intl.DateTimeFormat('en-KE', {
          timeZone: 'Africa/Nairobi', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false
        }).format(updated);
      }
      const hostSeconds = dashboard.botHost && dashboard.botHost.uptimeSeconds;
      const botSeconds = dashboard.botHost && dashboard.botHost.botUptimeSeconds;
      setText('host-uptime', formatDuration(hostSeconds == null ? null : hostSeconds + elapsed) || 'Not available');
      setText('bot-uptime', formatDuration(botSeconds == null ? null : botSeconds + elapsed) || 'Not detected');
    }
  }

  function appendText(parent, tag, className, value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    node.textContent = value;
    parent.appendChild(node);
    return node;
  }

  function safeHttps(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== 'https:' || url.username || url.password) return null;
      return url.href;
    } catch {
      return null;
    }
  }

  function renderMachineOptions(options) {
    const container = byId('machine-options');
    container.replaceChildren();
    if (!Array.isArray(options) || !options.length) {
      appendText(container, 'p', 'empty-note', 'No supported configuration data was returned.');
      return;
    }
    for (const option of options) {
      const card = document.createElement('article');
      card.className = 'size-option';
      appendText(card, 'span', 'size-cpu', `${option.vcpu} vCPU`);
      appendText(card, 'strong', 'size-ram', `${option.memoryGiB} GiB`);
      appendText(card, 'span', 'size-label', 'RAM');
      container.appendChild(card);
    }
  }

  function renderMachines(user) {
    const list = byId('vps-list');
    list.replaceChildren();
    const machines = Array.isArray(user.machines) ? user.machines : [];
    setText('vps-list-count', `${user.vpsCount} VPS${user.vpsCount === 1 ? '' : 's'}`);
    if (!machines.length) {
      appendText(list, 'p', 'empty-note', 'No VPS records are linked to your account yet.');
      return;
    }
    for (const machine of machines) {
      const card = document.createElement('article');
      card.className = 'vps-card';
      const top = document.createElement('div');
      top.className = 'vps-card-top';
      const title = document.createElement('div');
      title.className = 'vps-title';
      appendText(title, 'h3', '', machine.name || 'Unnamed VPS');
      appendText(title, 'span', `machine-status status-${String(machine.status || 'unknown').toLowerCase().replace(/[^a-z0-9_-]/g, '')}`, machine.status || 'Unknown');
      top.appendChild(title);
      card.appendChild(top);
      const specParts = [];
      if (Number.isSafeInteger(machine.vcpu) && machine.vcpu > 0) specParts.push(`${machine.vcpu} vCPU`);
      const memory = formatBytes(machine.memoryBytes);
      if (memory) specParts.push(memory);
      if (machine.region) specParts.push(String(machine.region).toUpperCase());
      appendText(card, 'p', 'vps-meta', specParts.join(' · ') || 'Specifications not available');
      if (machine.customDomain || machine.domain) {
        appendText(card, 'p', 'vps-domain', machine.customDomain || machine.domain);
      }
      const link = safeHttps(machine.url);
      if (link) {
        const open = appendText(card, 'a', 'vps-open', 'Open VPS ↗');
        open.href = link;
        open.target = '_blank';
        open.rel = 'noopener noreferrer';
      }
      list.appendChild(card);
    }
  }

  function render(data) {
    dashboard = data;
    receivedAt = Date.now();
    const user = data.user || {};
    const quota = data.boxd && data.boxd.quota || {};
    const stats = data.stats || {};
    const host = data.botHost || {};
    const regions = Array.isArray(data.boxd && data.boxd.enabledRegions) ? data.boxd.enabledRegions : [];

    const greetingName = [user.firstName, user.lastName].filter(Boolean).join(' ').trim();
    setText('greeting', greetingName ? `Welcome, ${greetingName}` : 'Your VPS dashboard');
    setText('quota-remaining', quota.remaining);
    setText('quota-used', quota.used);
    setText('quota-limit', quota.limit);
    const meter = byId('quota-meter');
    const fill = byId('quota-meter-fill');
    if (meter && fill && Number.isFinite(Number(quota.limit)) && Number(quota.limit) > 0) {
      const usedPercent = Math.max(0, Math.min(100, Math.round((Number(quota.used) / Number(quota.limit)) * 100)));
      meter.setAttribute('aria-valuemax', String(quota.limit));
      meter.setAttribute('aria-valuenow', String(quota.used));
      fill.style.width = `${usedPercent}%`;
    }
    setText('region-list', regions.length ? `Enabled: ${regions.map(region => region.name || region.id).join(', ')}` : 'Enabled regions: none reported');
    setText('users-count', stats.users);
    setText('vps-count', stats.totalVps);
    setText('active-vps-count', stats.activeVps);
    setText('user-vps-count', user.vpsCount);
    setText('host-name', host.name || 'Bot host');
    const hostSpecParts = [];
    if (Number.isSafeInteger(host.vcpu) && host.vcpu > 0) hostSpecParts.push(`${host.vcpu} vCPU`);
    const hostMemory = formatBytes(host.memoryBytes);
    if (hostMemory) hostSpecParts.push(hostMemory);
    setText('host-specs', hostSpecParts.length ? hostSpecParts.join(' · ') : 'Host specifications not available');
    const hostStatus = String(host.status || 'unknown');
    const statusPill = byId('host-status');
    statusPill.className = `status-pill ${hostStatus.toLowerCase() === 'running' ? 'is-running' : 'is-unknown'}`;
    const dot = document.createElement('span');
    dot.className = 'status-dot';
    dot.setAttribute('aria-hidden', 'true');
    statusPill.replaceChildren(dot, document.createTextNode(hostStatus));

    if (user.isAdmin) setText('coin-balance', 'Admin · free VPS creation');
    else setText('coin-balance', `${user.coinBalance} coins`);
    const economy = data.economy || {};
    setText('vps-cost', user.isAdmin ? 'Free for admins' : `${economy.vpsCost} coins`);
    setText('daily-reward', `+${economy.dailyReward} coins`);
    renderMachineOptions(data.machineOptions);
    renderMachines(user);

    const updated = new Date(data.updatedAt || Date.now());
    const updatedElement = byId('updated-at');
    updatedElement.dateTime = updated.toISOString();
    updatedElement.textContent = new Intl.DateTimeFormat('en-KE', {
      timeZone: 'Africa/Nairobi', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false
    }).format(updated);
    statusNode.textContent = 'Live data loaded securely for your Telegram account.';
    statusNode.classList.add('is-success');
    updateClock();
  }

  async function loadDashboard() {
    if (!telegram || typeof telegram.initData !== 'string' || !telegram.initData) {
      statusNode.textContent = 'Open this Mini App from the TRASHCORE bot in Telegram to load your secure live dashboard.';
      statusNode.classList.remove('is-success');
      byId('outside-hint').hidden = false;
      return;
    }
    if (refreshButton) refreshButton.disabled = true;
    statusNode.textContent = dashboard ? 'Refreshing live data…' : 'Verifying your Telegram session and loading live data…';
    statusNode.classList.remove('is-success');
    try {
      const response = await fetch('/api/dashboard', {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ initData: telegram.initData })
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload && payload.message || 'Live dashboard data is unavailable.');
      render(payload);
      if (refreshTimer) clearTimeout(refreshTimer);
      refreshTimer = setTimeout(loadDashboard, 60000);
    } catch (error) {
      statusNode.textContent = error && error.message || 'Live dashboard data is unavailable. Try refreshing.';
      statusNode.classList.remove('is-success');
    } finally {
      if (refreshButton) refreshButton.disabled = false;
    }
  }

  function returnToBot() {
    if (telegram && typeof telegram.close === 'function') {
      telegram.close();
      return;
    }
    byId('outside-hint').hidden = false;
    byId('outside-hint').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  document.querySelectorAll('.bot-action').forEach(button => button.addEventListener('click', returnToBot));
  if (refreshButton) refreshButton.addEventListener('click', loadDashboard);
  if (menu) {
    menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => { menu.open = false; }));
  }
  const panelLinks = document.querySelectorAll('a[href="https://panel.drextrash.online/"]');
  panelLinks.forEach(link => link.addEventListener('click', event => {
    if (telegram && typeof telegram.openLink === 'function') {
      event.preventDefault();
      telegram.openLink(panelUrl);
    }
  }));

  updateClock();
  setInterval(updateClock, 1000);
  loadDashboard();
})();
