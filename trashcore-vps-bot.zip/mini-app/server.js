const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { DashboardError, getDashboardData } = require('./lib/dashboard-data');

const STATIC_FILES = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
  ['/styles.css', ['styles.css', 'text/css; charset=utf-8']]
]);
const MAX_BODY_BYTES = 16 * 1024;
let boxdClientPromise = null;
let sharedBoxdClient = null;

function sendJson(res, status, body) {
  const encoded = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': encoded.length,
    'Cache-Control': 'no-store, max-age=0',
    Pragma: 'no-cache'
  });
  res.end(encoded);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    let settled = false;
    req.on('data', chunk => {
      if (settled) return;
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        settled = true;
        reject(new DashboardError('request_too_large', 413));
        req.resume();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      try {
        const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('invalid');
        settled = true;
        resolve(body);
      } catch {
        settled = true;
        reject(new DashboardError('invalid_request', 400));
      }
    });
    req.on('error', () => {
      if (settled) return;
      settled = true;
      reject(new DashboardError('invalid_request', 400));
    });
  });
}

async function getSharedBoxdClient() {
  if (sharedBoxdClient) return sharedBoxdClient;
  if (!boxdClientPromise) {
    boxdClientPromise = (async () => {
      const apiKey = String(process.env.BOXD_API_KEY || '').trim();
      if (!apiKey) throw new DashboardError('boxd_data_unavailable', 503);
      const { Boxd } = await import('@boxd-sh/sdk');
      sharedBoxdClient = new Boxd({ apiKey });
      return sharedBoxdClient;
    })().catch(error => {
      boxdClientPromise = null;
      throw error;
    });
  }
  return boxdClientPromise;
}

async function loadLiveDashboard(initData) {
  const machineId = String(process.env.BOT_DATA_MACHINE_ID || '').trim();
  const region = String(process.env.BOT_DATA_REGION || 'fra').trim();
  if (!machineId) throw new DashboardError('bot_runtime_unavailable', 503);
  const boxd = await getSharedBoxdClient();
  return getDashboardData({ initData, boxd, machineId, region });
}

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' https://telegram.org; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'");
}

function sendStatic(res, req, staticDirectory) {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  const entry = STATIC_FILES.get(pathname);
  if (!entry) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end('Not found');
    return;
  }
  const [filename, contentType] = entry;
  const filePath = path.join(staticDirectory, filename);
  let content;
  try {
    content = fs.readFileSync(filePath);
  } catch {
    res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end('Mini App assets are unavailable.');
    return;
  }
  res.writeHead(200, {
    'Content-Type': contentType,
    'Content-Length': content.length,
    'Cache-Control': pathname === '/' || pathname === '/index.html' ? 'no-cache' : 'public, max-age=60'
  });
  res.end(req.method === 'HEAD' ? undefined : content);
}

function safeErrorResponse(error) {
  if (error instanceof DashboardError) {
    const messages = {
      unauthorized: 'Open the Mini App from the TRASHCORE bot again to refresh your secure Telegram session.',
      user_not_registered: 'Send /start to the TRASHCORE bot once, then reopen the Mini App.',
      bot_auth_unavailable: 'The bot authentication service is temporarily unavailable.',
      bot_runtime_unavailable: 'The bot runtime is temporarily unavailable.',
      bot_data_unavailable: 'Bot account data is temporarily unavailable.',
      boxd_data_unavailable: 'Boxd live data is temporarily unavailable.',
      invalid_request: 'The request could not be read.',
      request_too_large: 'The request is too large.'
    };
    return { status: error.status || 503, body: { error: error.code, message: messages[error.code] || 'The request could not be completed.' } };
  }
  return { status: 503, body: { error: 'dashboard_unavailable', message: 'Live dashboard data is temporarily unavailable.' } };
}

function createMiniAppServer(options = {}) {
  const staticDirectory = options.staticDirectory || __dirname;
  const loadDashboard = options.loadDashboard || loadLiveDashboard;
  const expectedOrigin = new URL(options.expectedOrigin || process.env.MINIAPP_ORIGIN || 'https://dash.drex-vps.boxd.sh').origin;

  return http.createServer(async (req, res) => {
    securityHeaders(res);
    let pathname;
    try {
      pathname = new URL(req.url, 'http://localhost').pathname;
    } catch {
      res.writeHead(400, { 'Cache-Control': 'no-store' });
      return res.end();
    }

    if (pathname === '/healthz' && (req.method === 'GET' || req.method === 'HEAD')) {
      return sendJson(res, 200, { ok: true });
    }

    if (pathname === '/api/dashboard') {
      if (req.method !== 'POST') {
        res.writeHead(405, { Allow: 'POST', 'Cache-Control': 'no-store' });
        return res.end();
      }
      if (req.headers.origin !== expectedOrigin) {
        return sendJson(res, 403, { error: 'origin_not_allowed', message: 'This request is not allowed.' });
      }
      if (!/^application\/json(?:;|$)/i.test(String(req.headers['content-type'] || ''))) {
        return sendJson(res, 415, { error: 'json_required', message: 'A JSON request is required.' });
      }
      try {
        const body = await readJsonBody(req);
        if (typeof body.initData !== 'string' || !body.initData || Buffer.byteLength(body.initData, 'utf8') > 8192) {
          throw new DashboardError('unauthorized', 401);
        }
        const dashboard = await loadDashboard(body.initData);
        return sendJson(res, 200, dashboard);
      } catch (error) {
        const safe = safeErrorResponse(error);
        return sendJson(res, safe.status, safe.body);
      }
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD', 'Cache-Control': 'no-store' });
      return res.end();
    }
    return sendStatic(res, req, staticDirectory);
  });
}

function start() {
  const port = Number(process.env.PORT || 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be a valid TCP port.');
  const server = createMiniAppServer();
  server.listen(port, '0.0.0.0', () => console.log(`[mini-app] listening on port ${port}`));
  const shutdown = () => server.close(async () => {
    if (sharedBoxdClient && typeof sharedBoxdClient.close === 'function') {
      await sharedBoxdClient.close().catch(() => {});
    }
    process.exit(0);
  });
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
  return server;
}

if (require.main === module) start();

module.exports = { createMiniAppServer, loadLiveDashboard, safeErrorResponse };
