require('dotenv').config();
const path = require('node:path');
const { normalizeWebAppUrl } = require('./lib/mini-app');
const { parseTargets } = require('./lib/membership');

const adminIds = String(process.env.ADMIN_IDS || '')
  .split(',').map(value => value.trim()).filter(Boolean);
if (adminIds.some(id => !/^\d+$/.test(id))) {
  throw new Error('ADMIN_IDS must contain only comma-separated Telegram numeric user IDs.');
}

module.exports = {
  botToken: String(process.env.BOT_TOKEN || '').trim(),
  boxdApiKey: String(process.env.BOXD_API_KEY || '').trim(),
  webAppUrl: normalizeWebAppUrl(process.env.WEBAPP_URL),
  adminIds,
  requiredChats: parseTargets(process.env.REQUIRED_CHANNELS, process.env.REQUIRED_GROUPS),
  botName: process.env.BOT_NAME || 'TRASHCORE VPS BOT',
  dbPath: path.resolve(process.env.DB_PATH || path.join(__dirname, 'database.sqlite')),
  menuImage: path.join(__dirname, 'assets', 'trashcore-vps-welcome.png'),
  initialCredits: Number.isSafeInteger(Number(process.env.INITIAL_CREDITS))
    ? Math.max(0, Number(process.env.INITIAL_CREDITS)) : 0,
  vpsCost: 100,
  dailyReward: 10,
  timezone: 'Africa/Nairobi'
};
