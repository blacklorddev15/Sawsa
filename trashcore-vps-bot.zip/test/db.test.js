const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'trashcore-db-test-'));
process.env.DB_PATH = path.join(dir, 'test.sqlite');
process.env.INITIAL_CREDITS = '0';
const db = require('../lib/db');

test('claims daily coins once and reserves/refunds the VPS cost', () => {
  db.registerUser('10001', 'tester');
  assert.equal(db.getUser('10001').credits, 0);
  assert.deepEqual(db.claimDaily('10001', '2026-11-17', 10), { ok: true, credits: 10 });
  assert.deepEqual(db.claimDaily('10001', '2026-11-17', 10), { ok: false, credits: 10 });
  for (let day = 18; day <= 26; day++) db.claimDaily('10001', `2026-11-${day}`, 10);
  assert.equal(db.getUser('10001').credits, 100);
  assert.equal(db.reserveCredits('10001', 100), true);
  assert.equal(db.getUser('10001').credits, 0);
  assert.equal(db.reserveCredits('10001', 100), false);
  assert.equal(db.refundCredits('10001', 100), true);
  assert.equal(db.getUser('10001').credits, 100);
});

test('saves machine region and access details under the owning Telegram user', () => {
  db.registerUser('10002', 'owner');
  db.saveMachine({
    id: 'vm-1', telegram_id: '10002', name: 'tc-10002-abc', status: 'running',
    domain: 'tc-10002-abc.nyc.boxd.sh', url: 'https://tc-10002-abc.nyc.boxd.sh',
    ssh_port: 43210, vcpu: 2, memory_bytes: 8 * 1024 ** 3, region: 'nyc',
    image: 'ubuntu:24.04', public_ip: '203.0.113.11', custom_domain: null,
    created_at: '2026-11-17T00:00:00.000Z'
  });
  const row = db.getMachine('vm-1', '10002');
  assert.equal(row.region, 'nyc');
  assert.equal(row.public_ip, '203.0.113.11');
  assert.equal(db.getMachine('vm-1', '10003'), undefined);
  db.setCustomDomain('panel.example.test', 'vm-1', '10002');
  assert.equal(db.getMachine('vm-1', '10002').custom_domain, 'panel.example.test');
});

test.after(() => {
  db.close();
  fs.rmSync(dir, { recursive: true, force: true });
});
