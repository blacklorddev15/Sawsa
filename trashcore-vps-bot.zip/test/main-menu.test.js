const test = require('node:test');
const assert = require('node:assert/strict');
const { buildMainMenuKeyboard, restoreMainMenu, CHANNEL_URL, CONTACT_OWNER_URL } = require('../lib/main-menu');

test('main menu keeps its existing actions and adds Channel and Contact Owner links', () => {
  const rows = buildMainMenuKeyboard('https://dash.example.test/', false);

  assert.deepEqual(rows[0], [{ text: '🌐 Open Mini App', web_app: { url: 'https://dash.example.test/' }, style: 'primary' }]);
  assert.deepEqual(rows[1].map(button => button.callback_data), ['menu_create', 'menu_vps']);
  assert.deepEqual(rows.at(-1), [
    { text: '📣 Channel', url: CHANNEL_URL, style: 'primary' },
    { text: '👤 Contact Owner', url: CONTACT_OWNER_URL, style: 'primary' }
  ]);
  assert.equal(CHANNEL_URL, 'https://t.me/trashcore2');
  assert.equal(CONTACT_OWNER_URL, 'https://t.me/trashcoredev2');
  assert.equal(rows.some(row => row.some(button => button.callback_data === 'menu_help')), true);
  assert.equal(rows[0].length, 1, 'the Mini App launch row spans the available width');
  assert.ok(rows.every(row => row.length === 1 || row.length === 2), 'rows use full-width singles or two-column pairs with no spacer buttons');
});

test('admin menu keeps its admin action and includes links without a Mini App row', () => {
  const rows = buildMainMenuKeyboard('', true);

  assert.deepEqual(rows.at(-2), [
    { text: '📣 Channel', url: CHANNEL_URL, style: 'primary' },
    { text: '👤 Contact Owner', url: CONTACT_OWNER_URL, style: 'primary' }
  ]);
  assert.deepEqual(rows.at(-1), [{ text: '👑 Admin Stats', callback_data: 'menu_admin', style: 'primary' }]);
  assert.equal(rows.some(row => row.some(button => button.web_app)), false);
});

test('Back to Menu rebuilds the same screen with the current user main keyboard', async () => {
  const message = { chat: { id: 17 }, message_id: 91 };
  const result = { message_id: 91, updated: true };
  let rendered;
  const actual = await restoreMainMenu(message, '42', {
    webAppUrl: 'https://dash.example.test/',
    isAdmin: userId => userId === '42',
    startText: async userId => `welcome for ${userId}`,
    showScreen: async (...args) => { rendered = args; return result; }
  });

  assert.equal(actual, result);
  assert.equal(rendered[0], message);
  assert.equal(rendered[1], 'welcome for 42');
  assert.deepEqual(rendered[2], buildMainMenuKeyboard('https://dash.example.test/', true));
});
