const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const appDir = path.join(__dirname, '..', 'mini-app');
const html = fs.readFileSync(path.join(appDir, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(appDir, 'styles.css'), 'utf8');
const js = fs.readFileSync(path.join(appDir, 'app.js'), 'utf8');
const frontend = `${html}\n${css}\n${js}`;

test('Mini App has a mobile Telegram shell, accessible top-left menu, and existing Panel action', () => {
  assert.match(html, /name="viewport"[^>]*width=device-width/);
  assert.match(html, /telegram\.org\/js\/telegram-web-app\.js/);
  assert.match(html, /<details class="nav-menu"/);
  assert.match(html, /aria-label="Open dashboard menu"/);
  assert.match(html, /id="help"/);
  assert.match(html, /id="coins"/);
  assert.match(css, /safe-area-inset-top/);
  assert.match(css, /@media \(max-width: 520px\)/);
  assert.match(js, /telegram\.close\(\)/);
  assert.match(js, /https:\/\/panel\.drextrash\.online\//);
});

test('Mini App requests signed Telegram initData and never trusts initDataUnsafe', () => {
  assert.match(js, /telegram\.initData/);
  assert.match(js, /\/api\/dashboard/);
  assert.doesNotMatch(frontend, /initDataUnsafe/);
  assert.match(js, /credentials:\s*'same-origin'/);
  assert.match(js, /cache:\s*'no-store'/);
});

test('dashboard has quota, account, host uptime, time, supported configurations, and owner-scoped VPS sections', () => {
  for (const id of ['quota-remaining', 'quota-used', 'quota-limit', 'users-count', 'active-vps-count', 'host-uptime', 'bot-uptime', 'clock', 'machine-options', 'coin-balance', 'vps-list', 'help']) {
    assert.match(html, new RegExp(`id="${id}"`));
  }
  assert.match(html, /quota remainder, not physical machine inventory/i);
  assert.match(html, /Private to your account/);
  assert.match(html, /Contact owner/);
  assert.match(js, /Africa\/Nairobi/);
  assert.match(js, /safeHttps/);
  assert.match(js, /textContent/);
  assert.doesNotMatch(js, /innerHTML/);
});

test('frontend contains no Boxd or bot credentials and no invented live counts', () => {
  assert.doesNotMatch(frontend, /BOXD_API_KEY|BOT_TOKEN|Authorization:\s*Bearer|api[_-]?key\s*[:=]/i);
  assert.doesNotMatch(frontend, /fake|mock|sample machine|\b\d+\s+(?:active )?VPSs?\b/i);
});

test('Telegram display names retain Unicode and use emoji-capable system font fallbacks safely', () => {
  assert.match(css, /"Apple Color Emoji"/);
  assert.match(css, /"Segoe UI Emoji"/);
  assert.match(css, /"Noto Color Emoji"/);
  assert.match(js, /setText\('greeting', greetingName \? `Welcome, \$\{greetingName\}`/);
  assert.match(js, /element\.textContent = value == null \|\| value === '' \? '—' : String\(value\)/);
  assert.doesNotMatch(js, /innerHTML/);
  assert.match(html, /styles\.css\?v=20261118-emoji1/);
});
