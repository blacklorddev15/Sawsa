const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeCustomDomain, domainRecords, resolveBoxdProxyIp, verifyCustomDomainDns } = require('../lib/domain');

function fakeDoh({ apex = [], wildcard = [], machine = [] } = {}) {
  return async input => {
    const url = new URL(input);
    const name = url.searchParams.get('name');
    const type = url.searchParams.get('type');
    let answers = [];
    if (name === 'panel.example.test' && type === 'A') answers = apex.map(data => ({ type: 1, data }));
    else if (name === '*.panel.example.test' && type === 'CNAME') answers = wildcard.map(data => ({ type: 5, data }));
    else if (name === 'boxd-machine.boxd.sh' && type === 'A') answers = machine.map(data => ({ type: 1, data }));
    return { ok: true, async json() { return { Status: 0, Answer: answers }; } };
  };
}

test('validates and canonicalizes public custom hostnames', () => {
  assert.equal(normalizeCustomDomain('  Panel.Example.test. '), 'panel.example.test');
  assert.throws(() => normalizeCustomDomain('https://panel.example.test'), /hostname only/i);
  assert.throws(() => normalizeCustomDomain('*.example.test'), /hostname only/i);
  assert.throws(() => normalizeCustomDomain('boxd.sh'), /domain you control/i);
  assert.throws(() => normalizeCustomDomain('127.0.0.1'), /valid public domain/i);
});

test('formats exact apex A and wildcard CNAME DNS records', () => {
  assert.deepEqual(domainRecords('panel.example.test', '203.0.113.11', 'boxd-machine.boxd.sh'), [
    { type: 'A', host: 'panel.example.test.', value: '203.0.113.11' },
    { type: 'CNAME', host: '*.panel.example.test.', value: 'boxd-machine.boxd.sh.' }
  ]);
  assert.throws(() => domainRecords('panel.example.test', 'not-an-ip', 'boxd-machine.boxd.sh'), /public IP/i);
});

test('resolves a Boxd machine hostname to its shared proxy IPv4 from mocked DNS', async () => {
  const resolver = fakeDoh({ machine: ['203.0.113.11'] });
  assert.equal(await resolveBoxdProxyIp({ domain: 'boxd-machine.boxd.sh' }, resolver), '203.0.113.11');
});

test('only reports DNS as ready when both expected A and wildcard CNAME match', async () => {
  const resolver = fakeDoh({ apex: ['203.0.113.11'], wildcard: ['boxd-machine.boxd.sh.'] });
  assert.deepEqual(await verifyCustomDomainDns('panel.example.test', '203.0.113.11', 'boxd-machine.boxd.sh', resolver), {
    ok: true, aMatch: true, cnameMatch: true,
    observedA: ['203.0.113.11'], observedCname: ['boxd-machine.boxd.sh'],
    expectedIp: '203.0.113.11', expectedTarget: 'boxd-machine.boxd.sh'
  });
  const wrong = fakeDoh({ apex: ['203.0.113.12'], wildcard: ['wrong.boxd.sh'] });
  const result = await verifyCustomDomainDns('panel.example.test', '203.0.113.11', 'boxd-machine.boxd.sh', wrong);
  assert.equal(result.ok, false);
  assert.equal(result.aMatch, false);
  assert.equal(result.cnameMatch, false);
});
