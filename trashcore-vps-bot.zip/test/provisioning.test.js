const test = require('node:test');
const assert = require('node:assert/strict');
const { SIZES, buildCreateOptions, enabledRegions } = require('../lib/provisioning');

test('builds Boxd-supported VPS payloads and leaves image selection to Boxd', () => {
  const payload = buildCreateOptions({ name: 'tc-12345-abc123', sizeKey: '4x16G', region: 'fra' });
  assert.deepEqual(payload, {
    name: 'tc-12345-abc123', region: 'fra',
    config: { vcpu: 4, memory: '16G', ssh: true }
  });
  assert.equal(Object.hasOwn(payload, 'image'), false);
  assert.deepEqual(Object.keys(SIZES), ['1x4G', '2x8G', '4x16G', '8x32G']);
});

test('ignores legacy image overrides so Boxd default remains selected', () => {
  const payload = buildCreateOptions({ name: 'tc-12345-abc123', sizeKey: '2x8G', region: 'fra', image: 'ubuntu:24.04' });
  assert.equal(Object.hasOwn(payload, 'image'), false);
});

test('refuses unsupported size, region, and unsafe machine name', () => {
  assert.throws(() => buildCreateOptions({ name: 'machine-abc', sizeKey: '4x8G', region: 'fra' }), /Unsupported Boxd machine size/);
  assert.throws(() => buildCreateOptions({ name: 'machine-abc', sizeKey: '2x8G', region: 'london' }), /Unsupported Boxd region/);
  assert.throws(() => buildCreateOptions({ name: '../bad', sizeKey: '2x8G', region: 'fra' }), /Invalid machine name/);
});

test('lists only regions Boxd reports enabled for the organization', () => {
  assert.deepEqual(enabledRegions([
    { id: 'fra', name: 'Frankfurt', orgState: 'enabled', zone: 'boxd.sh' },
    { id: 'nyc', name: 'New York', orgState: 'available', zone: 'nyc.boxd.sh' },
    { id: 'xyz', name: 'Unknown', orgState: 'enabled', zone: 'xyz.example' }
  ]), [{ id: 'fra', name: 'Frankfurt', zone: 'boxd.sh' }]);
});
