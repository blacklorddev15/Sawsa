const test = require('node:test');
const assert = require('node:assert/strict');
const { sendMenuLayout } = require('../lib/menu-layout');

test('sends the welcome image, caption, and inline keyboard in one photo message', async () => {
  const calls = [];
  const photo = { message_id: 41, photo: [{ file_id: 'cached-photo' }] };
  const keyboard = { inline_keyboard: [[{ text: 'Open Mini App', web_app: { url: 'https://dash.example.test/' } }]] };
  const bot = {
    async sendPhoto(...args) { calls.push(['photo', ...args]); return photo; },
    async sendMessage(...args) { calls.push(['text', ...args]); throw new Error('text message must not be sent'); }
  };

  const result = await sendMenuLayout(bot, 123, ['menu.png'], '<b>Welcome</b>', keyboard);

  assert.deepEqual(result, { photoMessage: photo, menuMessage: photo });
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0], ['photo', 123, 'menu.png', {
    caption: '<b>Welcome</b>', parse_mode: 'HTML', reply_markup: keyboard
  }]);
});

test('falls back to the next photo source and keeps the caption and keyboard attached', async () => {
  const calls = [];
  const photoError = new Error('cached photo expired');
  const failures = [];
  const keyboard = { inline_keyboard: [[{ text: 'Channel', url: 'https://t.me/trashcore2' }]] };
  const photo = { message_id: 43, photo: [{ file_id: 'fresh-file-id' }] };
  const bot = {
    async sendPhoto(chatId, source, options) {
      calls.push(['photo', chatId, source, options]);
      if (source === 'stale-file-id') throw photoError;
      return photo;
    },
    async sendMessage(...args) { calls.push(['text', ...args]); throw new Error('text fallback not expected'); }
  };

  const result = await sendMenuLayout(bot, 456, ['stale-file-id', 'menu.png'], 'Menu', keyboard, (error, source) => failures.push([error, source]));

  assert.deepEqual(result, { photoMessage: photo, menuMessage: photo });
  assert.deepEqual(failures, [[photoError, 'stale-file-id']]);
  assert.deepEqual(calls.map(call => call.slice(0, 3)), [
    ['photo', 456, 'stale-file-id'],
    ['photo', 456, 'menu.png']
  ]);
  assert.deepEqual(calls[1][3], { caption: 'Menu', parse_mode: 'HTML', reply_markup: keyboard });
});

test('sends the text menu if every photo source fails', async () => {
  const calls = [];
  const uploadError = new Error('photo unavailable');
  const keyboard = { inline_keyboard: [] };
  const textMessage = { message_id: 44 };
  const bot = {
    async sendPhoto(...args) { calls.push(['photo', ...args]); throw uploadError; },
    async sendMessage(...args) { calls.push(['text', ...args]); return textMessage; }
  };

  const result = await sendMenuLayout(bot, 789, ['menu.png'], 'Text fallback', keyboard);

  assert.deepEqual(result, { photoMessage: null, menuMessage: textMessage });
  assert.deepEqual(calls[1], ['text', 789, 'Text fallback', { parse_mode: 'HTML', reply_markup: keyboard }]);
});

test('sends a keyboard-bearing text menu when there is no image', async () => {
  const calls = [];
  const keyboard = { inline_keyboard: [[{ text: 'Manage VPS', callback_data: 'menu_vps' }]] };
  const bot = {
    async sendPhoto() { assert.fail('no photo should be sent'); },
    async sendMessage(...args) { calls.push(args); return { message_id: 45 }; }
  };

  const result = await sendMenuLayout(bot, 789, [], 'Text-only menu', keyboard);

  assert.equal(result.photoMessage, null);
  assert.equal(result.menuMessage.message_id, 45);
  assert.deepEqual(calls[0], [789, 'Text-only menu', { parse_mode: 'HTML', reply_markup: keyboard }]);
});
