const test = require('node:test');
const assert = require('node:assert/strict');
const { createMiniAppServer, safeErrorResponse } = require('../mini-app/server');
const { DashboardError } = require('../mini-app/lib/dashboard-data');

const EXPECTED_ORIGIN = 'https://dashboard.test';

async function withServer(loadDashboard, run) {
  const server = createMiniAppServer({ expectedOrigin: EXPECTED_ORIGIN, loadDashboard });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}`;
  try { await run(baseUrl); }
  finally { await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())); }
}

function post(url, { origin = EXPECTED_ORIGIN, contentType = 'application/json', body = { initData: 'signed-data' } } = {}) {
  const headers = {};
  if (origin !== null) headers.Origin = origin;
  if (contentType !== null) headers['Content-Type'] = contentType;
  return fetch(`${url}/api/dashboard`, { method: 'POST', headers, body: typeof body === 'string' ? body : JSON.stringify(body) });
}

test('health and static page work with security headers', async () => {
  await withServer(async () => ({}), async baseUrl => {
    const health = await fetch(`${baseUrl}/healthz`);
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { ok: true });
    const page = await fetch(`${baseUrl}/`);
    assert.equal(page.status, 200);
    assert.match(page.headers.get('content-security-policy'), /default-src 'self'/);
    assert.equal(page.headers.get('x-content-type-options'), 'nosniff');
  });
});

test('dashboard API rejects missing or foreign origins and non-JSON requests', async () => {
  await withServer(async () => ({}), async baseUrl => {
    assert.equal((await post(baseUrl, { origin: null })).status, 403);
    assert.equal((await post(baseUrl, { origin: 'https://attacker.test' })).status, 403);
    assert.equal((await post(baseUrl, { contentType: 'text/plain' })).status, 415);
    assert.equal((await fetch(`${baseUrl}/api/dashboard`)).status, 405);
  });
});

test('dashboard API passes only the received initData to the authenticated data loader and disables caching', async () => {
  let received;
  await withServer(async initData => { received = initData; return { private: 'owner-only' }; }, async baseUrl => {
    const response = await post(baseUrl, { body: { initData: 'signed-init-data' } });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('cache-control'), 'no-store, max-age=0');
    assert.deepEqual(await response.json(), { private: 'owner-only' });
    assert.equal(received, 'signed-init-data');
  });
});

test('dashboard API rejects malformed or oversized identity data without returning details', async () => {
  await withServer(async () => ({}), async baseUrl => {
    const malformed = await post(baseUrl, { body: '{' });
    assert.equal(malformed.status, 400);
    const missing = await post(baseUrl, { body: {} });
    assert.equal(missing.status, 401);
    const tooLarge = await post(baseUrl, { body: { initData: 'x'.repeat(9000) } });
    assert.equal(tooLarge.status, 401);
  });
});

test('API error responses do not expose internal exception messages or credentials', () => {
  const safe = safeErrorResponse(new DashboardError('unauthorized', 401));
  assert.equal(safe.status, 401);
  assert.doesNotMatch(JSON.stringify(safe), /secret|token value|sql/i);
  const internal = safeErrorResponse(new Error('secret api key value failed'));
  assert.equal(internal.status, 503);
  assert.doesNotMatch(JSON.stringify(internal), /secret|api key value/i);
});
