const test = require('node:test');
const assert = require('node:assert/strict');
const { getAvailableMachineStock } = require('../lib/boxd-stock');

test('derives remaining slots from a mocked Boxd machine-limit response', async () => {
  let calls = 0;
  const mockBoxd = {
    orgs: {
      async getMachineLimit() {
        calls += 1;
        return { maxVms: 20, vmCount: 7 };
      }
    }
  };

  assert.deepEqual(await getAvailableMachineStock(mockBoxd), {
    available: 13,
    used: 7,
    limit: 20
  });
  assert.equal(calls, 1);
});

test('reports zero remaining slots when the quota is full or exceeded', async () => {
  const mockBoxd = {
    orgs: { async getMachineLimit() { return { maxVms: 5, vmCount: 5 }; } }
  };
  assert.deepEqual(await getAvailableMachineStock(mockBoxd), {
    available: 0,
    used: 5,
    limit: 5
  });
  const overLimitBoxd = {
    orgs: { async getMachineLimit() { return { maxVms: 5, vmCount: 6 }; } }
  };
  assert.deepEqual(await getAvailableMachineStock(overLimitBoxd), {
    available: 0,
    used: 6,
    limit: 5
  });
});

test('rejects invalid or unavailable machine-limit data', async () => {
  await assert.rejects(
    getAvailableMachineStock({ orgs: { async getMachineLimit() { return { maxVms: '5', vmCount: 1 }; } } }),
    /invalid machine-limit response/i
  );
  await assert.rejects(getAvailableMachineStock({ orgs: {} }), /does not provide/i);
});
