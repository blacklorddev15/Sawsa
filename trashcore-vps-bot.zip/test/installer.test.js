const test = require('node:test');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const realFs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const SOURCE_PATH = path.join(__dirname, '..', 'lib', 'installer.js');
const INSTALL_SCRIPT_PATH = path.join(__dirname, '..', 'scripts', 'install-panel-wings.sh');
const NIGHTSHIFT_SCRIPT_PATH = path.join(__dirname, '..', 'scripts', 'install-nightshift.sh');
const STATUS_PATH = '/tmp/trashcore-panel-wings-install.status';
const LOG_PATH = '/tmp/trashcore-panel-wings-install.log';
const PID_PATH = '/tmp/trashcore-panel-wings-install.pid';
const REMOTE_SCRIPT_PATH = '/tmp/trashcore-install-panel-wings.sh';
const REMOTE_RESUME_SCRIPT_PATH = '/tmp/trashcore-resume-panel-wings.sh';
const REMOTE_COMPOSE_TEMPLATE_PATH = '/tmp/trashcore-panel-stack.compose.yml';
const REMOTE_DOCKERFILE_TEMPLATE_PATH = '/tmp/trashcore-panel-runtime.Dockerfile';

function loadInstaller(getBoxd) {
  const fakeFs = Object.create(realFs);
  fakeFs.readFileSync = (file, encoding) => {
    if (String(file).endsWith('/scripts/install-panel-wings.sh')) return '# mocked installer script\n';
    return realFs.readFileSync(file, encoding);
  };
  const dependencies = {
    crypto: require('node:crypto'),
    fs: fakeFs,
    path,
    './boxd': { getBoxd }
  };
  const localRequire = id => Object.prototype.hasOwnProperty.call(dependencies, id)
    ? dependencies[id]
    : require(id);
  const module = { exports: {} };
  const source = realFs.readFileSync(SOURCE_PATH, 'utf8');
  new Function('require', 'module', '__filename', '__dirname', source)(
    localRequire, module, SOURCE_PATH, path.dirname(SOURCE_PATH)
  );
  return module.exports;
}

function makeMockStream({ stdout = ['==> Preflight\n'], stderr = [], exitCode = 0, holdOpen = false } = {}) {
  let finish;
  let closeCalls = 0;
  const finished = new Promise(resolve => { finish = resolve; });
  const finishWith = code => finish(code);
  const source = chunks => ({
    async *[Symbol.asyncIterator]() {
      for (const chunk of chunks) yield Buffer.from(chunk);
      if (holdOpen) await finished;
    }
  });
  const stream = {
    ...source(stdout),
    stderr: source(stderr),
    wait: () => holdOpen ? finished : Promise.resolve(exitCode),
    close() {
      closeCalls += 1;
      if (holdOpen) finishWith(130);
    }
  };
  return { stream, finish: finishWith, get closeCalls() { return closeCalls; } };
}

function createComposePreflightHarness({ installed = false, failInstall = false } = {}) {
  const source = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8');
  const functionSource = source.match(/^ensure_docker_compose_v2\(\)\s*\{\n[\s\S]*?^\}/m);
  assert.ok(functionSource, 'installer must define the Compose v2 preflight');

  const dir = realFs.mkdtempSync(path.join(os.tmpdir(), 'trashcore-compose-preflight-'));
  const binDir = path.join(dir, 'bin');
  const stateDir = path.join(dir, 'state');
  realFs.mkdirSync(binDir);
  realFs.mkdirSync(stateDir);
  const markerPath = path.join(stateDir, 'compose-present');
  if (installed) realFs.writeFileSync(markerPath, 'preinstalled plugin\n');
  realFs.writeFileSync(path.join(binDir, 'docker'), `#!/usr/bin/env bash
set -eu
printf 'docker %s\\n' "$*" >> "$MOCK_EVENTS"
case "$*" in
  --help)
    if [[ -f "$MOCK_STATE/compose-present" ]]; then
      printf 'Management Commands:\\n  compose* Docker Compose\\n'
    else
      printf 'Management Commands:\\n  container Manage containers\\n'
    fi
    ;;
  'compose version')
    [[ -f "$MOCK_STATE/compose-present" ]] || { echo 'docker: unknown command: docker compose' >&2; exit 1; }
    printf 'Docker Compose version v2.24.0\\n'
    ;;
  *) echo "unexpected docker invocation: $*" >&2; exit 90 ;;
esac
`);
  realFs.writeFileSync(path.join(binDir, 'apt-get'), `#!/usr/bin/env bash
set -eu
printf 'apt-get %s\\n' "$*" >> "$MOCK_EVENTS"
case "$*" in
  update) ;;
  'install -y docker-compose-v2')
    [[ "$MOCK_INSTALL_FAIL" == 0 ]] || exit 45
    printf 'mock-installed plugin\\n' > "$MOCK_STATE/compose-present"
    ;;
  *) echo "unexpected apt-get invocation: $*" >&2; exit 91 ;;
esac
`);
  realFs.chmodSync(path.join(binDir, 'docker'), 0o755);
  realFs.chmodSync(path.join(binDir, 'apt-get'), 0o755);
  const harnessPath = path.join(dir, 'preflight.sh');
  realFs.writeFileSync(harnessPath, `#!/usr/bin/env bash\n${functionSource[0]}\nensure_docker_compose_v2\n`);

  return {
    run() {
      return spawnSync('bash', [harnessPath], {
        encoding: 'utf8',
        env: {
          ...process.env,
          PATH: `${binDir}:${process.env.PATH}`,
          MOCK_EVENTS: path.join(dir, 'events.log'),
          MOCK_STATE: stateDir,
          MOCK_INSTALL_FAIL: failInstall ? '1' : '0'
        }
      });
    },
    events() {
      return realFs.existsSync(path.join(dir, 'events.log'))
        ? realFs.readFileSync(path.join(dir, 'events.log'), 'utf8').trim().split('\n')
        : [];
    },
    markerPath,
    cleanup() { realFs.rmSync(dir, { recursive: true, force: true }); }
  };
}

function mockedBoxd(calls, statusOutput, { failProtection = false, ignoreProtectionUpdate = false } = {}) {
  calls.botProtection ||= [];
  let botProtectionMode = 'on';
  const routes = [{ name: 'default', domain: 'panel.example.test' }];
  return {
    machines: {
      async get(id) { return { id, name: 'test-machine', status: 'running', botProtectionMode }; },
      async setBotProtection(id, mode, opts) {
        calls.botProtection.push({ id, mode, opts });
        if (failProtection) throw new Error('mock protection update failed');
        if (!ignoreProtectionUpdate) botProtectionMode = mode;
      },
      proxies: {
        async list() { return routes; },
        async setPort() {},
        async create(_name, name, port) { routes.push({ name, domain: 'wings.panel.example.test', port }); }
      },
      ports: {
        async list() { return [{ machinePort: 2022, protocol: 'tcp', publicPort: 32222 }]; },
        async expose() { throw new Error('not expected'); }
      },
      files: {
        async upload(...args) { calls.uploads.push(args); }
      },
      streamExec(...args) {
        calls.stream.push(args);
        const mock = calls.makeStream();
        calls.streamHandles.push(mock);
        return mock.stream;
      },
      async exec(...args) {
        calls.exec.push(args);
        const command = args[1].command;
        return command[2].includes('--- LOG TAIL ---')
          ? { success: true, stdout: statusOutput }
          : { success: true, stdout: '12345' };
      }
    },
    async close() { calls.closed += 1; }
  };
}

async function waitForMatch(file, pattern) {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (realFs.existsSync(file)) {
      const text = realFs.readFileSync(file, 'utf8');
      if (pattern.test(text)) return text;
    }
    await new Promise(resolve => setTimeout(resolve, 20));
  }
  assert.fail(`Timed out waiting for ${file} to match ${pattern}`);
}

async function waitForCondition(predicate) {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (predicate()) return;
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  assert.fail('Timed out waiting for condition');
}

test('keeps the foreground installer in a Boxd stream and verifies Preflight before returning', async () => {
  const heldStream = makeMockStream({ holdOpen: true });
  const calls = {
    uploads: [], exec: [], stream: [], streamHandles: [], closed: 0,
    makeStream: () => heldStream
  };
  const statusOutput = '2026-11-16T13:18:00Z | Installing dependencies\n--- LOG TAIL ---\napt-get update';
  const installer = loadInstaller(async () => mockedBoxd(calls, statusOutput));

  const details = await installer.prepareAndStart('mock-api-key', { id: 'machine-1', name: 'test-machine' });
  assert.deepEqual(calls.botProtection, [{ id: 'machine-1', mode: 'off', opts: { region: 'fra' } }],
    'only the selected machine is switched off through the machine-level API');
  assert.equal(calls.uploads.length, 3);
  assert.equal(calls.uploads[0][1], REMOTE_SCRIPT_PATH);
  assert.equal(calls.uploads[1][1], REMOTE_COMPOSE_TEMPLATE_PATH);
  assert.match(calls.uploads[1][2], /panel-scheduler:/);
  assert.equal(calls.uploads[2][1], REMOTE_DOCKERFILE_TEMPLATE_PATH);
  assert.match(calls.uploads[2][2], /FROM php:8\.3-fpm/);
  assert.equal(calls.stream.length, 1);
  assert.equal(calls.stream[0][0], 'machine-1');

  const streamParams = calls.stream[0][1];
  const launchCommand = streamParams.command[2];
  assert.deepEqual(streamParams.command.slice(0, 2), ['bash', '-lc']);
  assert.equal(streamParams.closeStdin, true);
  assert.equal(streamParams.timeout, undefined, 'the stream stays open until the installer finishes');
  assert.ok(launchCommand.includes(`: > '${LOG_PATH}'`));
  assert.ok(launchCommand.includes(`> '${STATUS_PATH}'`));
  assert.ok(launchCommand.includes(`rm -f '${PID_PATH}'`));
  assert.ok(launchCommand.includes("'Starting installer'"));
  assert.ok(launchCommand.includes(`printf '%s\\n' "$$" > '${PID_PATH}'`));
  assert.ok(launchCommand.includes(`exec bash '${REMOTE_SCRIPT_PATH}'`));
  assert.ok(!launchCommand.includes('setsid'));
  assert.ok(!launchCommand.includes('nohup'));
  assert.ok(!launchCommand.includes('& launcher=$!'));
  assert.ok(!launchCommand.includes(details.adminPassword), 'do not embed the generated password in the command line');
  assert.equal(streamParams.env.PANEL_DOMAIN, 'panel.example.test');
  assert.equal(streamParams.env.WINGS_DOMAIN, 'wings.panel.example.test');
  assert.equal(streamParams.env.PANEL_ADMIN_PASSWORD, details.adminPassword);
  const parsed = spawnSync('bash', ['-n', '-c', launchCommand], { encoding: 'utf8' });
  assert.equal(parsed.status, 0, `stream command must parse: ${parsed.stderr}`);
  assert.equal(calls.closed, 0, 'the Boxd client remains open while the stream is active');

  const launchDir = realFs.mkdtempSync(path.join(os.tmpdir(), 'trashcore-launch-test-'));
  try {
    const localLog = path.join(launchDir, 'install.log');
    const localStatus = path.join(launchDir, 'install.status');
    const localPid = path.join(launchDir, 'install.pid');
    const localScript = path.join(launchDir, 'mock-installer.sh');
    realFs.writeFileSync(localScript, `#!/usr/bin/env bash
set -eu
test "$PANEL_DOMAIN" = panel.example.test
test "$SFTP_PUBLIC_PORT" = 32222
test -n "$PANEL_ADMIN_PASSWORD"
printf '%s | Mock Preflight\\n' "$(date -u +'%FT%TZ')" > '${localStatus}'
echo 'mock installer launched' >> '${localLog}'
sleep 0.1
`);
    const localLaunch = launchCommand
      .replaceAll(LOG_PATH, localLog)
      .replaceAll(STATUS_PATH, localStatus)
      .replaceAll(PID_PATH, localPid)
      .replaceAll(REMOTE_SCRIPT_PATH, localScript)
      .replace('if [ "$(id -u)" -eq 0 ]; then', 'if true; then');
    const launched = spawnSync('bash', ['-c', localLaunch], {
      encoding: 'utf8',
      env: { ...process.env, PANEL_DOMAIN: 'panel.example.test', WINGS_DOMAIN: 'wings.panel.example.test',
        PANEL_ADMIN_EMAIL: 'admin@panel.example.test', PANEL_ADMIN_USERNAME: 'admin',
        PANEL_ADMIN_PASSWORD: details.adminPassword, SFTP_PUBLIC_PORT: '32222',
        THEME_REPO: 'https://github.com/Tennor-modz/Nightshift-.git', THEME_COMMIT: 'ecf1f9b5ee52bad7a0339d025c4e994a8f41f836' }
    });
    assert.equal(launched.status, 0, `${launched.stderr}\n${launched.stdout}`);
    assert.match(realFs.readFileSync(localStatus, 'utf8'), /Mock Preflight/);
    assert.match(realFs.readFileSync(localLog, 'utf8'), /mock installer launched/);
    assert.match(realFs.readFileSync(localPid, 'utf8'), /^\d+\n$/);
  } finally {
    realFs.rmSync(launchDir, { recursive: true, force: true });
  }

  const result = await installer.readStatus('mock-api-key', 'machine-1');
  assert.equal(result, statusOutput);
  const poll = calls.exec[0][1].command[2];
  assert.ok(poll.includes(`cat '${STATUS_PATH}'`));
  assert.ok(poll.includes(`tail -n 18 '${LOG_PATH}'`));
  assert.ok(poll.includes(PID_PATH));
  assert.ok(poll.includes('kill -0'));
  assert.ok(poll.includes('STALLED:'));
  assert.ok(poll.includes('FAILED:'));
  assert.ok(poll.includes(' -ge 120 '));
  const parsedPoll = spawnSync('bash', ['-n', '-c', poll], { encoding: 'utf8' });
  assert.equal(parsedPoll.status, 0, `poll command must parse: ${parsedPoll.stderr}`);
  assert.equal(calls.exec[0][0], 'machine-1');
  assert.equal(calls.closed, 1, 'only the status-poll client has closed so far');

  heldStream.finish(0);
  await waitForCondition(() => calls.closed === 2);
  assert.equal(heldStream.closeCalls, 0, 'normal completion does not cancel the remote process group');
});

test('reports a remote stream that exits before Preflight and closes its client', async () => {
  const failedStream = makeMockStream({ stdout: [], stderr: ['mock shell launch error'], exitCode: 127 });
  const calls = {
    uploads: [], exec: [], stream: [], streamHandles: [], closed: 0,
    makeStream: () => failedStream
  };
  const installer = loadInstaller(async () => mockedBoxd(calls, 'unused'));
  await assert.rejects(
    installer.prepareAndStart('mock-api-key', { id: 'machine-1', name: 'test-machine' }),
    /Could not start installer.*exited before Preflight with code 127; stderr: mock shell launch error/
  );
  assert.equal(calls.stream.length, 1);
  assert.equal(failedStream.closeCalls, 1);
  assert.equal(calls.closed, 1);
});

test('resumes the existing install with the dedicated continuation script', async () => {
  const heldStream = makeMockStream({ stdout: ['==> Resuming Nightshift release build\n'], holdOpen: true });
  const calls = {
    uploads: [], exec: [], stream: [], streamHandles: [], closed: 0,
    makeStream: () => heldStream
  };
  const installer = loadInstaller(async () => mockedBoxd(calls, 'unused'));

  const result = await installer.prepareAndStart('mock-api-key', { id: 'machine-1', name: 'test-machine' }, { resume: true });
  assert.deepEqual(calls.botProtection, [], 'a Nightshift resume does not change Boxd bot protection');
  assert.equal(result.resumed, true);
  assert.equal(Object.hasOwn(result, 'adminPassword'), false, 'a retry must not generate or reveal a replacement admin password');
  assert.equal(calls.uploads.length, 4);
  assert.equal(calls.uploads[3][1], REMOTE_RESUME_SCRIPT_PATH);
  assert.match(calls.uploads[3][2], /Resuming Nightshift release build/);
  assert.equal(calls.stream.length, 1);
  const command = calls.stream[0][1].command[2];
  assert.ok(command.includes(`exec bash '${REMOTE_RESUME_SCRIPT_PATH}'`));
  assert.ok(!command.includes(`: > '${LOG_PATH}'`), 'a retry must preserve the existing installer log');
  assert.equal(calls.stream[0][1].env.PANEL_DOMAIN, 'panel.example.test');
  assert.equal(calls.stream[0][1].env.SFTP_PUBLIC_PORT, '32222');

  heldStream.finish(0);
  await waitForCondition(() => calls.closed === 1);
});

test('does not proceed with Panel/Wings setup if the selected machine protection update fails', async () => {
  const calls = { uploads: [], exec: [], stream: [], streamHandles: [], closed: 0, makeStream: () => makeMockStream() };
  const installer = loadInstaller(async () => mockedBoxd(calls, 'unused', { failProtection: true }));

  await assert.rejects(
    installer.prepareAndStart('mock-api-key', { id: 'machine-1', name: 'test-machine' }),
    /mock protection update failed/
  );
  assert.deepEqual(calls.botProtection, [{ id: 'machine-1', mode: 'off', opts: { region: 'fra' } }]);
  assert.equal(calls.uploads.length, 0, 'installer files are not uploaded if protection could not be changed');
  assert.equal(calls.stream.length, 0, 'the remote installer is not launched if protection could not be changed');
  assert.equal(calls.closed, 1, 'the Boxd client closes after the failed setup');
});

test('does not proceed unless Boxd confirms bot protection is off for the selected machine', async () => {
  const calls = { uploads: [], exec: [], stream: [], streamHandles: [], closed: 0, makeStream: () => makeMockStream() };
  const installer = loadInstaller(async () => mockedBoxd(calls, 'unused', { ignoreProtectionUpdate: true }));

  await assert.rejects(
    installer.prepareAndStart('mock-api-key', { id: 'machine-1', name: 'test-machine' }),
    /could not be verified off for this VPS/i
  );
  assert.deepEqual(calls.botProtection, [{ id: 'machine-1', mode: 'off', opts: { region: 'fra' } }]);
  assert.equal(calls.uploads.length, 0, 'no installer files are uploaded until the setting is verified');
  assert.equal(calls.stream.length, 0, 'the remote installer is not launched until the setting is verified');
  assert.equal(calls.closed, 1);
});

test('offers resume only for a failed Nightshift release-build step', () => {
  const source = realFs.readFileSync(SOURCE_PATH, 'utf8');
  const dependencies = {
    crypto: require('node:crypto'), fs: realFs, path,
    './boxd': { getBoxd: async () => ({}) }
  };
  const localRequire = id => Object.prototype.hasOwnProperty.call(dependencies, id) ? dependencies[id] : require(id);
  const module = { exports: {} };
  new Function('require', 'module', '__filename', '__dirname', source)(localRequire, module, SOURCE_PATH, path.dirname(SOURCE_PATH));
  const canResume = module.exports.canResumeNightshiftBuild;
  const failedNightshift = '2026-11-17T12:00:00Z | FAILED exit=127 line=0\n--- LOG TAIL ---\n==> Building the Nightshift release archive\n==> FAILED exit=127 line=0';
  assert.equal(canResume(failedNightshift), true);
  const truncatedYarnFailure = '...status header truncated...\n==> Building the Nightshift release archive\nsh: 1: yarn: command not found\n==> FAILED exit=127 line=0';
  assert.equal(canResume(truncatedYarnFailure), true, 'the failed build markers remain sufficient when readStatus truncates its header');
  assert.equal(canResume('2026-11-17T12:05:00Z | FAILED exit=1 line=1\n--- LOG TAIL ---\n==> Resuming Nightshift release build\n==> FAILED exit=1 line=1'), true);
  assert.equal(canResume('2026-11-17T12:00:00Z | Installing Panel dependencies\n--- LOG TAIL ---\n==> Installing Panel dependencies\n==> FAILED exit=1 line=1'), false);
  assert.equal(canResume('2026-11-17T12:00:00Z | FAILED exit=127 line=0\n--- LOG TAIL ---\n==> Building the Nightshift release archive\nsh: 1: yarn: command not found'), false, 'the most recent event must still explicitly report failure');
  assert.equal(canResume('2026-11-17T12:00:00Z | COMPLETE: done\n--- LOG TAIL ---\n==> Building the Nightshift release archive'), false);
});

test('offers Nightshift only after core completion and retries only its safe build failure', () => {
  const installer = require('../lib/installer');
  assert.equal(installer.isPanelWingsComplete('2026-11-17T12:00:00Z | COMPLETE: Docker-managed Panel and Wings containers are running.'), true);
  assert.equal(installer.isPanelWingsComplete('2026-11-17T12:00:00Z | FAILED exit=127 line=0'), false);
  assert.equal(installer.isNightshiftComplete('2026-11-17T12:10:00Z | COMPLETE: Nightshift theme is installed.'), true);
  assert.equal(installer.hasNightshiftAttempt('Nightshift installer status not available yet.\n--- LOG TAIL ---\nNo Nightshift installer log yet.'), false);

  const safeBuildFailure = '2026-11-17T12:00:00Z | FAILED exit=127 line=0\n--- LOG TAIL ---\n==> Building the Nightshift release archive\n==> FAILED exit=127 line=0';
  const safeSetupFailure = '2026-11-17T12:00:00Z | FAILED exit=1 line=0\n--- LOG TAIL ---\n==> Preparing the pinned Yarn 1.22.22 executable\n==> FAILED exit=1 line=0';
  const failedDuringApply = '2026-11-17T12:00:00Z | FAILED exit=1 line=0\n--- LOG TAIL ---\n==> Applying Nightshift to the installed Panel\n==> FAILED exit=1 line=0';
  assert.equal(installer.canRetryNightshiftBuild(safeBuildFailure), true);
  assert.equal(installer.canRetryNightshiftBuild(safeSetupFailure), true,
    'logged failures before applying the theme must remain safely retryable');
  assert.equal(installer.canRetryNightshiftBuild(failedDuringApply), false,
    'the bot must not automatically retry after theme application has started');
  assert.equal(installer.canRetryNightshiftBuild('2026-11-17T12:00:00Z | COMPLETE: done\n--- LOG TAIL ---\n==> Building the Nightshift release archive'), false);
});

test('does not start Nightshift until Panel and Wings report completion', async () => {
  const calls = { uploads: [], exec: [], stream: [], streamHandles: [], closed: 0, makeStream: () => makeMockStream() };
  const installer = loadInstaller(async () => mockedBoxd(calls,
    '2026-11-17T12:00:00Z | Installing Panel dependencies\n--- LOG TAIL ---\n==> Installing Panel dependencies'));
  await assert.rejects(
    installer.prepareNightshiftAndStart('mock-api-key', { id: 'machine-1', name: 'test-machine' }),
    /Panel and Wings must finish successfully/
  );
  assert.equal(calls.uploads.length, 0, 'Nightshift must not be uploaded or run before the core installer completes');
  assert.equal(calls.stream.length, 0);
});

test('installer reports a missing preflight variable as a terminal failure', () => {
  const dir = realFs.mkdtempSync(path.join(os.tmpdir(), 'trashcore-preflight-test-'));
  try {
    const localScript = path.join(dir, 'installer.sh');
    const logPath = path.join(dir, 'install.log');
    const statusPath = path.join(dir, 'install.status');
    const source = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8')
      .replace('LOG=/tmp/trashcore-panel-wings-install.log', `LOG=${logPath}`)
      .replace('STATUS=/tmp/trashcore-panel-wings-install.status', `STATUS=${statusPath}`);
    realFs.writeFileSync(localScript, source);
    const env = { ...process.env };
    for (const key of ['PANEL_DOMAIN', 'WINGS_DOMAIN', 'PANEL_ADMIN_EMAIL', 'PANEL_ADMIN_PASSWORD', 'SFTP_PUBLIC_PORT']) {
      delete env[key];
    }
    const result = spawnSync('bash', [localScript], { encoding: 'utf8', env });
    assert.equal(result.status, 2, `${result.stderr}\n${result.stdout}`);
    assert.match(realFs.readFileSync(logPath, 'utf8'), /Missing required environment variable: PANEL_DOMAIN/);
    assert.match(realFs.readFileSync(statusPath, 'utf8'), /\| FAILED exit=2 line=/);
  } finally {
    realFs.rmSync(dir, { recursive: true, force: true });
  }
});

test('installs Ubuntu Compose v2 before invoking Compose when the plugin is missing', () => {
  const harness = createComposePreflightHarness();
  try {
    const result = harness.run();
    assert.equal(result.status, 0, `${result.stderr}\n${result.stdout}`);
    assert.deepEqual(harness.events(), [
      'docker --help',
      'apt-get update',
      'apt-get install -y docker-compose-v2',
      'docker compose version'
    ]);

    const installer = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8');
    assert.ok(installer.indexOf('if ! ensure_docker_compose_v2; then') < installer.indexOf('docker info >/dev/null'),
      'the Compose preflight must finish before Docker health checks or stack commands');
    assert.match(realFs.readFileSync(harness.markerPath, 'utf8'), /mock-installed plugin/);
  } finally {
    harness.cleanup();
  }
});

test('leaves an existing Compose v2 plugin untouched', () => {
  const harness = createComposePreflightHarness({ installed: true });
  try {
    const result = harness.run();
    assert.equal(result.status, 0, `${result.stderr}\n${result.stdout}`);
    assert.deepEqual(harness.events(), ['docker --help', 'docker compose version']);
    assert.equal(realFs.readFileSync(harness.markerPath, 'utf8'), 'preinstalled plugin\n');
  } finally {
    harness.cleanup();
  }
});

test('reports a clear error when Ubuntu cannot install Compose v2', () => {
  const harness = createComposePreflightHarness({ failInstall: true });
  try {
    const result = harness.run();
    assert.notEqual(result.status, 0);
    assert.match(result.stdout, /Could not install Ubuntu package docker-compose-v2/);
    assert.deepEqual(harness.events(), [
      'docker --help',
      'apt-get update',
      'apt-get install -y docker-compose-v2'
    ]);
  } finally {
    harness.cleanup();
  }
});

test('installs Composer dependencies before invoking artisan key:generate', () => {
  const script = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8');
  const composerInstall = script.indexOf('run_composer install --no-dev --optimize-autoloader --no-interaction --prefer-dist');
  const keyGenerate = script.indexOf('APP_KEY="$(run_panel_php artisan key:generate --show --no-ansi)"');

  assert.notEqual(composerInstall, -1, 'the installer must install Panel Composer dependencies');
  assert.notEqual(keyGenerate, -1, 'the installer must generate a new Panel application key');
  assert.ok(composerInstall < keyGenerate,
    'artisan requires vendor dependencies, so Composer install must run first');
});

test('Panel PHP runtime includes the MySQL command-line client', () => {
  const dockerfile = realFs.readFileSync(
    path.join(__dirname, '..', 'scripts', 'panel-runtime.Dockerfile'), 'utf8'
  );
  assert.match(dockerfile, /^\s+default-mysql-client\s*\\?$/m,
    'Panel shell commands must have the mysql executable available in the PHP runtime');
});

test('starts healthy Panel PHP before validating the Nginx upstream hostname', () => {
  const script = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8');
  const nginxConfig = script.indexOf('chmod 644 "$STACK_DIR/nginx.conf"');
  const startPhp = script.indexOf('dc up -d panel-php', nginxConfig);
  const waitForPhp = script.indexOf('wait_for_healthy panel-php', startPhp);
  const nginxConfigTest = script.indexOf('dc run --rm --no-deps --entrypoint nginx panel-nginx -t');

  assert.notEqual(nginxConfig, -1, 'Nginx configuration must be written before validation');
  assert.notEqual(startPhp, -1, 'the PHP service must be started before Nginx validation');
  assert.notEqual(waitForPhp, -1, 'the PHP service must become healthy before Nginx validation');
  assert.notEqual(nginxConfigTest, -1, 'the installer must validate the Nginx configuration');
  assert.ok(nginxConfig < startPhp && startPhp < waitForPhp && waitForPhp < nginxConfigTest,
    'Nginx resolves panel-php during config validation, so its Compose DNS alias must exist first');
});

test('grants Nginx traversal on only the Panel root directory through a UID-specific ACL', () => {
  const script = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8');
  const grant = 'setfacl -m u:101:--x "$PANEL_DIR"';
  const lastOwnershipReset = script.lastIndexOf('chown -R 33:33 "$PANEL_DIR"');
  const grantPosition = script.indexOf(grant);
  const nginxSetup = script.indexOf('status "Configuring Nginx container"');
  const buildTools = script.match(/^apt-get install -y (.+)$/m)?.[1].split(/\s+/) || [];

  assert.ok(buildTools.includes('acl'), 'the installer must provide setfacl/getfacl');
  assert.deepEqual(script.match(/^setfacl\b[^\n]*$/gm) || [], [grant],
    'only the exact UID-101 execute-only ACL may be applied');
  assert.match(script, /^getfacl -ncp "\$PANEL_DIR" \| grep -qx 'user:101:--x'$/m,
    'the installer must verify the numeric UID-101 ACL before continuing');
  assert.ok(lastOwnershipReset >= 0 && grantPosition > lastOwnershipReset,
    'the traversal permission must be applied after the final Panel ownership reset');
  assert.ok(nginxSetup > grantPosition,
    'Nginx must receive traversal permission before its container is configured');
  assert.doesNotMatch(script, /^chmod o\+x "\$PANEL_DIR"$/m,
    'world-wide traversal must not be granted to the Panel root');
  assert.doesNotMatch(script, /^setfacl\s+-R\b/m,
    'the ACL must not be applied recursively');
  assert.doesNotMatch(script, /^chmod\s+-R\b[^\n]*"\$PANEL_DIR(?:\/[^"]*)?"/m,
    'Panel root traversal must not be granted with a recursive chmod');
});
test('retries transient Wings API startup failures before declaring installation failure', () => {
  const scriptPaths = [INSTALL_SCRIPT_PATH, path.join(__dirname, '..', 'scripts', 'resume-panel-wings.sh')];
  for (const scriptPath of scriptPaths) {
    const script = realFs.readFileSync(scriptPath, 'utf8');
    assert.match(script, /wait_for_http_code wings http:\/\/127\.0\.0\.1:8080\/api\/system '' '401 403 200'/);
    assert.doesNotMatch(script, /WINGS_CODE/, 'Wings must not be checked with a one-shot curl');
  }

  const source = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8');
  const helper = source.match(/^wait_for_http_code\(\)\s*\{\n[\s\S]*?^\}/m);
  assert.ok(helper, 'installer must define its bounded HTTP readiness retry');

  const dir = realFs.mkdtempSync(path.join(os.tmpdir(), 'trashcore-wings-readiness-'));
  const countPath = path.join(dir, 'curl-count');
  realFs.writeFileSync(countPath, '0');
  try {
    const harness = [
      'set -eu',
      helper[0],
      'dc() { printf "mock-wings-id\\n"; }',
      'sleep() { :; }',
      'curl() {',
      '  local attempt',
      '  attempt="$(cat "$MOCK_COUNT")"',
      '  attempt="$((attempt + 1))"',
      '  printf "%s" "$attempt" > "$MOCK_COUNT"',
      '  if (( attempt < 3 )); then printf "000"; return 7; fi',
      '  printf "401"',
      '}',
      "wait_for_http_code wings http://127.0.0.1:8080/api/system '' '401 403 200'",
      'printf "attempts=%s\\n" "$(cat "$MOCK_COUNT")"',
      ''
    ].join('\n');
    const result = spawnSync('bash', ['-c', harness], {
      encoding: 'utf8', env: { ...process.env, MOCK_COUNT: countPath }
    });
    assert.equal(result.status, 0, `${result.stderr}\n${result.stdout}`);
    assert.match(result.stdout, /attempts=3/,
      'HTTP 000 during startup must be retried until Wings returns an accepted API response');
  } finally {
    realFs.rmSync(dir, { recursive: true, force: true });
  }
});

test('service installer is systemd-free and Docker Compose owns persistent service restarts', t => {
  const script = realFs.readFileSync(INSTALL_SCRIPT_PATH, 'utf8');
  const resumeScript = realFs.readFileSync(path.join(__dirname, '..', 'scripts', 'resume-panel-wings.sh'), 'utf8');
  const nightshiftScript = realFs.readFileSync(NIGHTSHIFT_SCRIPT_PATH, 'utf8');
  const composeFile = path.join(__dirname, '..', 'scripts', 'panel-stack.compose.yml');
  const dockerfile = path.join(__dirname, '..', 'scripts', 'panel-runtime.Dockerfile');
  const compose = realFs.readFileSync(composeFile, 'utf8');
  const runtimeDockerfile = realFs.readFileSync(dockerfile, 'utf8');

  assert.doesNotMatch(script, /\bsystemctl\b|\/etc\/systemd\/|systemd\.service/);
  assert.match(script, /docker compose version/);
  assert.match(script, /verify_restart_policy/);
  assert.match(compose, /ghcr\.io\/pterodactyl\/wings:latest/);
  assert.match(compose, /MARIADB_ROOT_PASSWORD/);
  assert.match(compose, /panel-queue:/);
  assert.match(compose, /panel-scheduler:/);
  assert.equal([...compose.matchAll(/^\s*restart:\s*always\s*$/gm)].length, 7);
  const panelNetwork = compose.match(/^  panel:\n([\s\S]*?)(?=^  wings0:)/m);
  assert.ok(panelNetwork, 'Compose must define the Panel bridge network');
  assert.match(panelNetwork[1], /^\s+- subnet:\s+172\.20\.0\.0\/16$/m,
    'the Panel bridge must not consume Wings’ default 172.18.0.0/16 subnet');
  const wingsNetwork = compose.match(/^  wings0:\n([\s\S]*?)(?=^volumes:)/m);
  assert.ok(wingsNetwork, 'Compose must define the Wings bridge network');
  assert.match(wingsNetwork[1], /^\s+name: wings0$/m);
  assert.match(wingsNetwork[1], /^\s+driver: bridge$/m);
  assert.match(wingsNetwork[1], /^\s+com\.docker\.network\.bridge\.name: wings0$/m);
  assert.match(wingsNetwork[1], /^\s+- subnet:\s+172\.19\.0\.0\/16$/m,
    'the wings0 bridge must also stay outside Wings’ default 172.18.0.0/16 subnet');
  assert.doesNotMatch(compose, /^\s+- subnet:\s+172\.18\.0\.0\/16$/m,
    'Compose networks must leave 172.18.0.0/16 available for Wings');
  assert.match(runtimeDockerfile, /FROM php:8\.3-fpm/);
  assert.doesNotMatch(script, /Nightshift|\byarn\b/,
    'core Panel/Wings setup must not depend on the optional theme or its build tools');
  assert.match(nightshiftScript, /npm exec --yes --package=yarn@1\.22\.22 -- sh -c/);
  assert.match(nightshiftScript, /export PATH="\$YARN_BIN_DIR:\$PATH"/);
  assert.ok(nightshiftScript.indexOf('export PATH="$YARN_BIN_DIR:$PATH"') < nightshiftScript.indexOf('./release.sh'),
    'release.sh must inherit the pinned Yarn executable on PATH');
  assert.match(nightshiftScript, /THEME_APPLY_STARTED=1/);
  assert.match(nightshiftScript, /rollback_theme/);
  assert.match(resumeScript, /last_step.*Building the Nightshift release archive/s);
  assert.match(resumeScript, /run_yarn\(\)\{ npm exec --yes --package=yarn@1\.22\.22 -- yarn/);
  for (const [label, source] of [['Nightshift installer', nightshiftScript], ['Nightshift retry', resumeScript]]) {
    const zipCheck = source.indexOf('command -v zip >/dev/null 2>&1');
    const zipInstall = source.indexOf('apt-get install -y zip', zipCheck);
    const release = source.indexOf('env NODE_OPTIONS=--openssl-legacy-provider ./release.sh');
    assert.ok(zipCheck >= 0 && zipCheck < zipInstall && zipInstall < release,
      `${label} must ensure zip is installed before running release.sh`);
  }

  const shellSyntax = spawnSync('bash', ['-n', INSTALL_SCRIPT_PATH], { encoding: 'utf8' });
  assert.equal(shellSyntax.status, 0, `installer shell syntax must parse: ${shellSyntax.stderr}`);
  const nightshiftSyntax = spawnSync('bash', ['-n', NIGHTSHIFT_SCRIPT_PATH], { encoding: 'utf8' });
  assert.equal(nightshiftSyntax.status, 0, `Nightshift shell syntax must parse: ${nightshiftSyntax.stderr}`);
  const resumeSyntax = spawnSync('bash', ['-n', path.join(__dirname, '..', 'scripts', 'resume-panel-wings.sh')], { encoding: 'utf8' });
  assert.equal(resumeSyntax.status, 0, `resume shell syntax must parse: ${resumeSyntax.stderr}`);

  const composeVersion = spawnSync('docker', ['compose', 'version'], { encoding: 'utf8' });
  if (composeVersion.status !== 0) {
    t.diagnostic('Docker Compose CLI is unavailable; skipped Compose parser validation.');
    return;
  }

  const dir = realFs.mkdtempSync(path.join(os.tmpdir(), 'trashcore-compose-test-'));
  try {
    const runtimeDir = path.join(dir, 'runtime');
    realFs.mkdirSync(runtimeDir);
    realFs.copyFileSync(composeFile, path.join(dir, 'compose.yml'));
    realFs.copyFileSync(dockerfile, path.join(runtimeDir, 'Dockerfile'));
    realFs.writeFileSync(path.join(dir, 'nginx.conf'), 'server {}\n');
    realFs.writeFileSync(path.join(dir, '.env'), 'MARIADB_ROOT_PASSWORD=mock-root\nMARIADB_PASSWORD=mock-app\n');
    const parsed = spawnSync('docker', [
      'compose', '--project-directory', dir, '-f', path.join(dir, 'compose.yml'), 'config', '--quiet'
    ], { encoding: 'utf8' });
    assert.equal(parsed.status, 0, `Compose template must parse: ${parsed.stderr}\n${parsed.stdout}`);
  } finally {
    realFs.rmSync(dir, { recursive: true, force: true });
  }
});
