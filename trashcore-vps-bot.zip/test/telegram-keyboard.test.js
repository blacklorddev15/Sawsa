const test = require('node:test');
const assert = require('node:assert/strict');
const { styleInlineKeyboard } = require('../lib/telegram-keyboard');

test('styles Telegram buttons by action and leaves the Back button at default', () => {
  const rows = [
    [
      { text: 'Create VPS', callback_data: 'menu_create' },
      { text: 'Manage VPS', callback_data: 'menu_vps' }
    ],
    [
      { text: 'Retry installation', callback_data: 'vps_iretry:machine-1' },
      { text: 'Install Nightshift', callback_data: 'vps_nightshift:machine-1' },
      { text: 'Skip', callback_data: 'vps_nightshift_skip:machine-1' },
      { text: 'Retry Nightshift', callback_data: 'vps_nretry:machine-1' },
      { text: 'Cancel', callback_data: 'install_cancel' }
    ],
    [{ text: 'Back to menu', callback_data: 'menu_home' }]
  ];

  assert.deepEqual(styleInlineKeyboard(rows), [
    [
      { text: 'Create VPS', callback_data: 'menu_create', style: 'success' },
      { text: 'Manage VPS', callback_data: 'menu_vps', style: 'primary' }
    ],
    [
      { text: 'Retry installation', callback_data: 'vps_iretry:machine-1', style: 'success' },
      { text: 'Install Nightshift', callback_data: 'vps_nightshift:machine-1', style: 'success' },
      { text: 'Skip', callback_data: 'vps_nightshift_skip:machine-1', style: 'danger' },
      { text: 'Retry Nightshift', callback_data: 'vps_nretry:machine-1', style: 'success' },
      { text: 'Cancel', callback_data: 'install_cancel', style: 'danger' }
    ],
    [{ text: 'Back to menu', callback_data: 'menu_home' }]
  ]);
  assert.equal(Object.hasOwn(rows[0][0], 'style'), false, 'the input keyboard is not mutated');
});

test('preserves an explicitly selected Telegram button style', () => {
  const button = { text: 'Keep custom style', callback_data: 'menu_vps', style: 'success' };
  assert.deepEqual(styleInlineKeyboard([[button]]), [[button]]);
});
