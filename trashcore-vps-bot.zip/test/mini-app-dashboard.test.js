const test = require('node:test');
const assert = require('node:assert/strict');
const { buildRemoteDataCommand, buildRemoteDataScript } = require('../mini-app/lib/remote-query');
const { DashboardError, getDashboardData } = require('../mini-app/lib/dashboard-data');

const INIT_DATA = 'signed-telegram-init-data-for-test';

function boxdFixture(remoteData) {
  let execOptions;
  const boxd = {
    orgs: {
      getMachineLimit: async () => ({ maxVms: 100, vmCount: 3 }),
      regions: async () => [
        { id: 'fra', name: 'Frankfurt', orgState: 'enabled' },
        { id: 'nyc', name: 'New York', orgState: 'enabled' },
        { id: 'lon', name: 'London', orgState: 'requested' }
      ]
    },
    machines: {
      get: async id => ({ id, name: 'thin-clay', status: 'running', resources: { vcpu: 2, memoryBytes: 8589934592 } }),
      exec: async (_id, options) => { execOptions = options; return { stdout: JSON.stringify(remoteData) }; }
    }
  };
  return { boxd, getExecOptions: () => execOptions };
}

function remoteFixture(overrides = {}) {
  return {
    user: {
      firstName: 'Railer', lastName: '', username: 'railer', isAdmin: false,
      coinBalance: 230, lastDailyClaim: '2026-11-17', vpsCount: 1
    },
    stats: { users: 42, totalVps: 8, activeVps: 5 },
    machines: [{ name: 'private-vps', status: 'running', region: 'fra', vcpu: 2, memoryBytes: 8589934592, domain: 'private.boxd.sh', url: 'https://private.boxd.sh/', customDomain: '', createdAt: '2026-10-01T00:00:00.000Z' }],
    runtime: { hostUptimeSeconds: 86400.81, botUptimeSeconds: 3600 },
    serverTime: '2026-11-17T19:00:00.000Z',
    ...overrides
  };
}

test('remote query uses read-only SQLite, parameterized user filters, and no shell interpolation of initData', () => {
  const script = buildRemoteDataScript();
  const command = buildRemoteDataCommand();
  assert.match(script, /readonly:\s*true/);
  assert.match(script, /fileMustExist:\s*true/);
  assert.match(script, /WHERE telegram_id = \?/);
  assert.match(script, /path\.relative\(containerRoot, dbPath\)/);
  assert.match(script, /MINIAPP_INIT_DATA/);
  assert.doesNotMatch(command, new RegExp(INIT_DATA));
  assert.match(command, /--env MINIAPP_INIT_DATA="\$MINIAPP_INIT_DATA"/);
  assert.match(command, /docker exec/);
});

test('dashboard combines Boxd quota, supported configurations, host uptime, and user-owned data', async () => {
  const fixture = boxdFixture(remoteFixture());
  const data = await getDashboardData({ initData: INIT_DATA, boxd: fixture.boxd, machineId: 'thin-clay', region: 'fra' });
  assert.deepEqual(data.boxd.quota, { limit: 100, used: 3, remaining: 97 });
  assert.deepEqual(data.boxd.enabledRegions, [{ id: 'fra', name: 'Frankfurt' }, { id: 'nyc', name: 'New York' }]);
  assert.equal(data.botHost.name, 'thin-clay');
  assert.equal(data.botHost.vcpu, 2);
  assert.equal(data.botHost.memoryBytes, 8589934592);
  assert.equal(data.botHost.uptimeSeconds, 86400);
  assert.equal(data.botHost.botUptimeSeconds, 3600);
  assert.equal(data.stats.users, 42);
  assert.equal(data.user.coinBalance, 230);
  assert.equal(data.user.machines[0].name, 'private-vps');
  assert.equal(data.economy.vpsCost, 100);
  assert.equal(data.economy.dailyReward, 10);
  assert.equal(data.machineOptions.length, 4);
  const execOptions = fixture.getExecOptions();
  assert.equal(execOptions.env.MINIAPP_INIT_DATA, INIT_DATA);
  assert.doesNotMatch(execOptions.command, new RegExp(INIT_DATA));
});

test('admin receives no numeric coin balance and admin VPS creation is free', async () => {
  const remote = remoteFixture({ user: { firstName: 'Admin', isAdmin: true, coinBalance: null, vpsCount: 0 }, machines: [] });
  const { boxd } = boxdFixture(remote);
  const data = await getDashboardData({ initData: INIT_DATA, boxd, machineId: 'thin-clay' });
  assert.equal(data.user.isAdmin, true);
  assert.equal(data.user.coinBalance, null);
  assert.equal(data.economy.vpsCost, 100);
});

test('dashboard rejects malformed counts and maps remote authorization failures safely', async () => {
  const { boxd } = boxdFixture(remoteFixture({ stats: { users: -1, totalVps: 0, activeVps: 0 } }));
  await assert.rejects(getDashboardData({ initData: INIT_DATA, boxd, machineId: 'thin-clay' }), error => error instanceof DashboardError && error.code === 'bot_data_unavailable');

  const unauthorizedBoxd = boxdFixture({ error: 'unauthorized' }).boxd;
  await assert.rejects(getDashboardData({ initData: INIT_DATA, boxd: unauthorizedBoxd, machineId: 'thin-clay' }), error => error instanceof DashboardError && error.code === 'unauthorized' && error.status === 401);
});

test('dashboard refuses to invent bot uptime if process discovery is unavailable', async () => {
  const { boxd } = boxdFixture(remoteFixture({ runtime: { hostUptimeSeconds: 12, botUptimeSeconds: null } }));
  const data = await getDashboardData({ initData: INIT_DATA, boxd, machineId: 'thin-clay' });
  assert.equal(data.botHost.botUptimeSeconds, null);
});

test('dashboard preserves emoji and Unicode in Telegram display names', async () => {
  const remote = remoteFixture({ user: {
    firstName: 'Railer 😎', lastName: '🌍✨', username: 'railer', isAdmin: false,
    coinBalance: 230, lastDailyClaim: null, vpsCount: 0
  }, machines: [] });
  const { boxd } = boxdFixture(remote);
  const data = await getDashboardData({ initData: INIT_DATA, boxd, machineId: 'thin-clay' });

  assert.equal(data.user.firstName, 'Railer 😎');
  assert.equal(data.user.lastName, '🌍✨');
  assert.equal(data.user.username, 'railer');
});
