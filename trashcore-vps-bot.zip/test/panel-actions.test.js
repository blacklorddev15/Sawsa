const test = require('node:test');
const assert = require('node:assert/strict');
const {
  postInstallActionRows,
  PUBLIC_IP_UNAVAILABLE,
  ALLOCATIONS_UNAVAILABLE
} = require('../lib/panel-actions');

test('shows public IP and allocation actions only after Panel + Wings completion', () => {
  assert.deepEqual(postInstallActionRows('machine-1', false), []);
  assert.deepEqual(postInstallActionRows('machine-1', true), [
    [{ text: '🌐 Get public IP', callback_data: 'vps_publicip:machine-1' }],
    [{ text: '🔌 Assign allocations', callback_data: 'vps_allocations:machine-1' }]
  ]);
});

test('explains that the Boxd proxy is not a direct machine IP and allocations need unsupported credentials', () => {
  assert.match(PUBLIC_IP_UNAVAILABLE, /shared proxy IP/i);
  assert.match(PUBLIC_IP_UNAVAILABLE, /direct, routable IP/i);
  assert.match(ALLOCATIONS_UNAVAILABLE, /Application API token/i);
  assert.match(ALLOCATIONS_UNAVAILABLE, /no change was made/i);
  assert.match(ALLOCATIONS_UNAVAILABLE, /limited to three per machine/i);
});
