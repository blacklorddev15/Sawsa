const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeWebAppUrl, miniAppLaunchRow } = require('../lib/mini-app');

test('accepts only absolute HTTPS Mini App URLs without embedded credentials', () => {
  assert.equal(normalizeWebAppUrl(' https://dash.example.test/app?from=bot '), 'https://dash.example.test/app?from=bot');
  assert.equal(normalizeWebAppUrl(''), '');
  assert.throws(() => normalizeWebAppUrl('dash.example.test'), /absolute HTTPS/i);
  assert.throws(() => normalizeWebAppUrl('http://dash.example.test'), /absolute HTTPS/i);
  assert.throws(() => normalizeWebAppUrl('https://user:pass@dash.example.test'), /without embedded credentials/i);
});

test('builds a Telegram web_app button and omits it when no URL is configured', () => {
  assert.deepEqual(miniAppLaunchRow('https://dash.example.test/'), [
    [{ text: '🌐 Open Mini App', web_app: { url: 'https://dash.example.test/' } }]
  ]);
  assert.deepEqual(miniAppLaunchRow(''), []);
});
