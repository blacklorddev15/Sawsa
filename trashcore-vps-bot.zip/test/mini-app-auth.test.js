const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { validateTelegramInitData } = require('../mini-app/lib/telegram-auth');

const TOKEN = 'unit-test-only-token-no-credentials';
const NOW_MS = 1_700_000_000_000;

function signedInitData({ user = { id: 12345, first_name: 'Test', last_name: 'User', username: 'test_user' }, authDate = Math.floor(NOW_MS / 1000), token = TOKEN } = {}) {
  const entries = [
    ['auth_date', String(authDate)],
    ['query_id', 'AAE-test-query'],
    ['user', JSON.stringify(user)]
  ];
  const check = entries.slice().sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => `${key}=${value}`).join('\n');
  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(token).digest();
  const hash = crypto.createHmac('sha256', secretKey).update(check).digest('hex');
  return new URLSearchParams([...entries, ['hash', hash]]).toString();
}

test('Telegram initData authenticates the signed user and returns only expected identity fields', () => {
  const result = validateTelegramInitData(signedInitData(), TOKEN, { nowMs: NOW_MS });
  assert.deepEqual(result, {
    user: { id: '12345', firstName: 'Test', lastName: 'User', username: 'test_user' },
    authDate: Math.floor(NOW_MS / 1000)
  });
});

test('Telegram initData rejects a changed user payload', () => {
  const tampered = new URLSearchParams(signedInitData());
  tampered.set('user', JSON.stringify({ id: 98765, first_name: 'Someone else' }));
  assert.throws(() => validateTelegramInitData(tampered.toString(), TOKEN, { nowMs: NOW_MS }), /invalid_init_data/);
});

test('Telegram initData rejects duplicate parameters and malformed hashes', () => {
  const valid = signedInitData();
  assert.throws(() => validateTelegramInitData(`${valid}&hash=${'a'.repeat(64)}`, TOKEN, { nowMs: NOW_MS }), /invalid_init_data/);
  const badHash = new URLSearchParams(valid);
  badHash.set('hash', 'nope');
  assert.throws(() => validateTelegramInitData(badHash.toString(), TOKEN, { nowMs: NOW_MS }), /invalid_init_data/);
});

test('Telegram initData rejects stale and future-dated authentication', () => {
  const stale = signedInitData({ authDate: Math.floor(NOW_MS / 1000) - 3601 });
  assert.throws(() => validateTelegramInitData(stale, TOKEN, { nowMs: NOW_MS, maxAgeSeconds: 3600 }), /expired_init_data/);
  const future = signedInitData({ authDate: Math.floor(NOW_MS / 1000) + 61 });
  assert.throws(() => validateTelegramInitData(future, TOKEN, { nowMs: NOW_MS, clockSkewSeconds: 60 }), /expired_init_data/);
});

test('Telegram initData rejects missing bot authentication secret and invalid user IDs', () => {
  assert.throws(() => validateTelegramInitData(signedInitData(), '', { nowMs: NOW_MS }), /auth_unavailable/);
  const invalidUser = signedInitData({ user: { id: 0, first_name: 'Invalid' } });
  assert.throws(() => validateTelegramInitData(invalidUser, TOKEN, { nowMs: NOW_MS }), /invalid_init_data/);
});
