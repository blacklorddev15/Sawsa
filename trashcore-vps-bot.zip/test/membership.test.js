const test = require('node:test');
const assert = require('node:assert/strict');
const { parseTargets, joinRows, createMembershipGate } = require('../lib/membership');

test('parses channel and group links, usernames and private ids from .env values', () => {
  const targets = parseTargets('https://t.me/trashcore2, @second_chan', '-1001234567890|https://t.me/+AbCdEf');
  assert.deepEqual(targets.map(t => [t.kind, t.label, t.chatId, t.url]), [
    ['channel', 'Channel 1', '@trashcore2', 'https://t.me/trashcore2'],
    ['channel', 'Channel 2', '@second_chan', 'https://t.me/second_chan'],
    ['group', 'Group', '-1001234567890', 'https://t.me/+AbCdEf']
  ]);
  assert.deepEqual(parseTargets('', ''), []);
  assert.deepEqual(joinRows(targets.slice(2)), [[{ text: '👥 Join Group', url: 'https://t.me/+AbCdEf' }]]);
});

test('rejects invite links without a chat id and ids without links', () => {
  assert.throws(() => parseTargets('https://t.me/+AbCdEf', ''), /private chats/);
  assert.throws(() => parseTargets('', '-1001234567890'), /needs a join link/);
});

function fakeBot(statuses) {
  return { async getChatMember(chatId, userId) {
    const value = statuses[`${chatId}:${userId}`];
    if (value instanceof Error) throw value;
    return value || { status: 'left' };
  } };
}

test('requires membership in every chat, lets admins through, and caches success', async () => {
  const targets = parseTargets('@chan_one', '@group_one');
  let clock = 0;
  const bot = fakeBot({
    '@chan_one:1': { status: 'member' }, '@group_one:1': { status: 'administrator' },
    '@chan_one:2': { status: 'member' }, '@group_one:2': { status: 'left' },
    '@chan_one:3': { status: 'restricted', is_member: true }, '@group_one:3': { status: 'creator' }
  });
  const gate = createMembershipGate({ bot, targets, isAdmin: id => String(id) === '9', now: () => clock });

  assert.equal((await gate.check('1')).ok, true);
  const partial = await gate.check('2');
  assert.equal(partial.ok, false);
  assert.deepEqual(partial.results.map(r => r.state), ['joined', 'missing']);
  assert.equal((await gate.check('3')).ok, true);
  assert.equal((await gate.check('9')).ok, true, 'admins bypass the gate');

  bot.getChatMember = async () => { throw new Error('should be served from cache'); };
  assert.equal((await gate.check('1')).ok, true);
  clock = 200000;
  assert.equal((await gate.check('1')).ok, false, 'cache expires and the live check runs again');
});

test('treats unreadable chats as unverifiable, not as joined, and a disabled gate as open', async () => {
  const targets = parseTargets('@chan_one', '');
  const bot = fakeBot({ '@chan_one:5': new Error('Bad Request: chat not found') });
  const original = console.error; console.error = () => {};
  const verdict = await createMembershipGate({ bot, targets }).check('5');
  console.error = original;
  assert.equal(verdict.ok, false);
  assert.equal(verdict.results[0].state, 'error');
  assert.equal((await createMembershipGate({ bot, targets: [] }).check('5')).ok, true);
});

test('diagnose reports what Telegram says about each chat, the bot and the user', async () => {
  const targets = parseTargets('@chan_one', '@group_one');
  const bot = {
    async getMe() { return { id: 99 }; },
    async getChat(id) {
      if (id === '@group_one') throw new Error('ETELEGRAM: 400 Bad Request: chat not found');
      return { id: -1001, title: 'Chan', type: 'channel' };
    },
    async getChatMember(chat, id) { return { status: id === 99 ? 'administrator' : 'left' }; }
  };
  const lines = await createMembershipGate({ bot, targets }).diagnose('7');
  const text = lines.join('\n');
  assert.match(text, /id -1001 \| channel/);
  assert.match(text, /bot: administrator/);
  assert.match(text, /you: left/);
  assert.match(text, /getChat FAILED: 400 Bad Request: chat not found/);
});
