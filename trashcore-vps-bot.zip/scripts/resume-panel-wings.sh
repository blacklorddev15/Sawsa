#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
LOG=/tmp/trashcore-panel-wings-install.log
STATUS=/tmp/trashcore-panel-wings-install.status
LOCK=/tmp/trashcore-panel-wings-install.lock
PANEL_DIR=/var/www/pterodactyl
STACK_DIR=/opt/trashcore-panel-stack
THEME_REPO="${THEME_REPO:-https://github.com/Tennor-modz/Nightshift-.git}"
THEME_COMMIT="${THEME_COMMIT:-ecf1f9b5ee52bad7a0339d025c4e994a8f41f836}"
: "${PANEL_DOMAIN:?PANEL_DOMAIN is required}"
: "${WINGS_DOMAIN:?WINGS_DOMAIN is required}"
: "${SFTP_PUBLIC_PORT:?SFTP_PUBLIC_PORT is required}"
status(){ printf '%s | %s\n' "$(date -u +'%FT%TZ')" "$1" > "$STATUS"; chmod 644 "$STATUS"; echo "==> $1"; }
trap 'rc=$?; if (( rc != 0 )); then status "FAILED exit=$rc line=${BASH_LINENO[0]:-unknown}"; fi' EXIT

if [[ ! -s "$LOG" || ! -f "$PANEL_DIR/.env" || ! -f "$PANEL_DIR/artisan" || ! -s "$STACK_DIR/compose.yml" ]]; then
  echo "The existing Panel installation is incomplete; this retry can only resume the Nightshift build stage."
  exit 3
fi
last_event="$(grep '^==> ' "$LOG" | tail -n 1 || true)"
last_step="$(grep '^==> ' "$LOG" | grep -v '^==> FAILED' | tail -n 1 || true)"
if [[ ( "$last_step" != '==> Building the Nightshift release archive' && "$last_step" != '==> Resuming Nightshift release build' ) || "$last_event" != '==> FAILED '* ]]; then
  echo "The most recent failed step is not the Nightshift release build; refusing to restart from an unsafe point."
  exit 3
fi
exec 9>"$LOCK"
if ! flock -n 9; then
  echo "Another installer process is already running."
  status "FAILED: Another installer process is already running."
  exit 8
fi

exec > >(tee -a "$LOG") 2>&1
dc(){ docker compose --project-directory "$STACK_DIR" -f "$STACK_DIR/compose.yml" "$@"; }
run_panel_php(){ dc run --rm --no-deps --user 33:33 --entrypoint php panel-php "$@"; }
run_composer(){ dc run --rm --no-deps --user 33:33 --entrypoint composer panel-php "$@"; }
run_yarn(){ npm exec --yes --package=yarn@1.22.22 -- yarn "$@"; }
db_root_query(){
  local sql="$1"
  dc exec -T database sh -lc 'MYSQL_PWD="$MARIADB_ROOT_PASSWORD" exec mariadb -N -uroot panel -e "$1"' query "$sql"
}
wait_for_healthy(){
  local service="$1" id state health attempt
  id="$(dc ps -q "$service")"
  [[ -n "$id" ]] || { echo "No container was created for $service."; return 1; }
  for attempt in $(seq 1 90); do
    state="$(docker inspect --format '{{.State.Status}}' "$id" 2>/dev/null || true)"
    health="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$id" 2>/dev/null || true)"
    [[ "$health" == healthy ]] && return 0
    if [[ "$state" == exited || "$state" == dead ]]; then
      docker logs --tail 40 "$id" >&2 || true
      echo "$service container stopped in state $state."
      return 1
    fi
    sleep 2
  done
  docker logs --tail 40 "$id" >&2 || true
  echo "Timed out waiting for $service to become healthy (last state=$state, health=$health)."
  return 1
}
verify_restart_policy(){
  local service="$1" id policy
  id="$(dc ps -q "$service")"
  [[ -n "$id" ]] || { echo "No running container for $service."; return 1; }
  policy="$(docker inspect --format '{{.HostConfig.RestartPolicy.Name}}' "$id")"
  [[ "$policy" == always ]] || { echo "$service has restart policy '$policy', expected 'always'."; return 1; }
}
wait_for_http_code(){
  local label="$1" url="$2" host_header="$3" accepted="$4" id code attempt
  id="$(dc ps -q "$label")"
  for attempt in $(seq 1 30); do
    code="$(curl -sS --max-time 5 -o /dev/null -w '%{http_code}' ${host_header:+-H "$host_header"} "$url" 2>/dev/null || true)"
    case " $accepted " in *" $code "*) return 0;; esac
    sleep 2
  done
  [[ -z "$id" ]] || docker logs --tail 60 "$id" >&2 || true
  echo "$label did not return an expected HTTP status from $url (last status: ${code:-none})."
  return 1
}

status "Resuming Nightshift release build"
export DEBIAN_FRONTEND=noninteractive
command -v git >/dev/null || apt-get install -y git
command -v npm >/dev/null || { echo "npm is not available; cannot run the pinned Yarn package."; exit 4; }
THEME_DIR=/opt/Nightshift
rm -rf "$THEME_DIR"
git init "$THEME_DIR"
git -C "$THEME_DIR" remote add origin "$THEME_REPO"
git -C "$THEME_DIR" fetch --depth 1 origin "$THEME_COMMIT"
git -C "$THEME_DIR" checkout --detach FETCH_HEAD
[[ "$(git -C "$THEME_DIR" rev-parse HEAD)" == "$THEME_COMMIT" ]]
grep -q "'version' => '1.15.2'" "$THEME_DIR/config/app.php" || { echo "Pinned Nightshift source does not match Panel 1.15.2."; exit 21; }
run_yarn --version
cd "$THEME_DIR"
run_yarn install --frozen-lockfile
mkdir -p public/assets
NODE_OPTIONS=--openssl-legacy-provider run_yarn build:production
chmod +x ./release.sh
if ! command -v zip >/dev/null 2>&1; then
  status "Installing zip for the Nightshift release build"
  apt-get update
  apt-get install -y zip
fi
env NODE_OPTIONS=--openssl-legacy-provider ./release.sh
THEME_ARCHIVE="$THEME_DIR/release/panel.tar.gz"
[[ -s "$THEME_ARCHIVE" ]] || { echo "Nightshift release.sh did not create release/panel.tar.gz."; exit 21; }
tar -tzf "$THEME_ARCHIVE" >/dev/null

status "Applying Nightshift to the installed Panel"
BACKUP="/root/nightshift-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp -a "$PANEL_DIR/resources" "$BACKUP/resources"
cp -a "$PANEL_DIR/tailwind.config.js" "$BACKUP/" 2>/dev/null || true
cd "$PANEL_DIR"
run_panel_php artisan down || true
tar -xzf "$THEME_ARCHIVE" -C "$PANEL_DIR" --exclude='./.env' --exclude='./storage' --exclude='./storage/*'
chown -R 33:33 "$PANEL_DIR"
run_composer install --no-dev --optimize-autoloader --no-interaction --prefer-dist
run_yarn install --frozen-lockfile
if [[ -f "$PANEL_DIR/resources/scripts/theme.ts" && -d "$PANEL_DIR/resources/scripts/theme" ]]; then
  mv "$PANEL_DIR/resources/scripts/theme.ts" "$BACKUP/theme.ts.old"
fi
status "Building production assets with Nightshift"
NODE_OPTIONS=--openssl-legacy-provider run_yarn build:production
run_panel_php artisan up
run_panel_php artisan optimize:clear
run_panel_php artisan queue:restart
chown -R 33:33 "$PANEL_DIR"
chmod -R 755 "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache"
chmod 640 "$PANEL_DIR/.env"

status "Configuring Panel node and Wings"
install -d -m 755 /etc/pterodactyl /var/lib/pterodactyl/volumes /var/log/pterodactyl /tmp/pterodactyl /run/wings
LOC_SHORT="bx$(date +%s | tail -c 5)"
run_panel_php artisan p:location:make --short="$LOC_SHORT" --long="Boxd Machine" --no-interaction
LOCATION_ID="$(db_root_query "SELECT id FROM locations WHERE short='${LOC_SHORT}' LIMIT 1;")"
[[ "$LOCATION_ID" =~ ^[0-9]+$ ]]
MEM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
NODE_MEM="$((MEM_MB-1024))"
DISK_MB="$(df -Pm / | awk 'NR==2{print $2}')"
NODE_DISK="$((DISK_MB-4096))"
(( NODE_MEM > 512 && NODE_DISK > 4096 ))
run_panel_php artisan p:node:make \
  --name="Boxd-$(hostname -s)" --description="Single-machine Panel and Wings" \
  --locationId="$LOCATION_ID" --fqdn="$WINGS_DOMAIN" --public=1 --scheme=https \
  --proxy=1 --maintenance=0 --maxMemory="$NODE_MEM" --overallocateMemory=0 \
  --maxDisk="$NODE_DISK" --overallocateDisk=0 --uploadSize=100 \
  --daemonListeningPort=443 --daemonSFTPPort="$SFTP_PUBLIC_PORT" \
  --daemonBase=/var/lib/pterodactyl/volumes --no-interaction
NODE_ID="$(db_root_query "SELECT id FROM nodes WHERE fqdn='${WINGS_DOMAIN}' ORDER BY id DESC LIMIT 1;")"
[[ "$NODE_ID" =~ ^[0-9]+$ ]]
run_panel_php artisan p:node:configuration "$NODE_ID" > /etc/pterodactyl/config.yml
test -s /etc/pterodactyl/config.yml
chmod 600 /etc/pterodactyl/config.yml
sed -i '/^api:/,/^[^ ]/ s/^  port:.*/  port: 8080/' /etc/pterodactyl/config.yml
sed -i '/^  ssl:/,/^[^ ]/ s/^    enabled:.*/    enabled: false/' /etc/pterodactyl/config.yml
sed -i '/^  sftp:/,/^[^ ]/ s/^    bind_port:.*/    bind_port: 2022/' /etc/pterodactyl/config.yml
grep -q '^  port: 8080$' /etc/pterodactyl/config.yml
grep -q '^    bind_port: 2022$' /etc/pterodactyl/config.yml

status "Starting Docker-managed Panel and Wings services"
dc up -d --build panel-php panel-nginx panel-queue panel-scheduler wings
for service in database redis panel-php panel-nginx panel-queue panel-scheduler wings; do
  verify_restart_policy "$service"
done
wait_for_healthy database
wait_for_healthy redis
wait_for_healthy panel-php
wait_for_healthy panel-nginx
for service in panel-queue panel-scheduler wings; do
  id="$(dc ps -q "$service")"
  [[ -n "$id" ]] || { echo "$service did not remain running."; exit 1; }
  state="$(docker inspect --format '{{.State.Status}}' "$id")"
  [[ "$state" == running ]] || { docker logs --tail 60 "$id" >&2 || true; echo "$service is not running (state=$state)."; exit 1; }
done
PANEL_CODE="$(curl -sS --max-time 10 -o /dev/null -w '%{http_code}' -H "Host: ${PANEL_DOMAIN}" http://127.0.0.1/ || true)"
[[ "$PANEL_CODE" == 200 || "$PANEL_CODE" == 302 ]] || { docker logs --tail 60 "$(dc ps -q panel-nginx)" >&2 || true; echo "Panel returned HTTP ${PANEL_CODE:-no response}."; exit 1; }
wait_for_http_code wings http://127.0.0.1:8080/api/system '' '401 403 200'
status "COMPLETE: Docker-managed Panel and Wings containers are running; verify public Boxd HTTPS proxy and console WebSocket."
echo "PANEL_URL=https://${PANEL_DOMAIN}"
echo "WINGS_URL=https://${WINGS_DOMAIN}:443"
echo "NODE_ID=${NODE_ID}"
echo "SFTP_PUBLIC_PORT=${SFTP_PUBLIC_PORT}"
echo "THEME_BACKUP=${BACKUP}"
echo "SERVICE_MANAGER=Docker restart policies (Boxd documents Docker starting at boot); no systemd dependency."
echo "NOTE=Game allocations are not auto-created; Boxd raw TCP/UDP forwards are limited to three per machine."
