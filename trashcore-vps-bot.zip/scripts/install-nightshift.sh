#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
LOG=/tmp/trashcore-nightshift-install.log
STATUS=/tmp/trashcore-nightshift-install.status
LOCK=/tmp/trashcore-nightshift-install.lock
CORE_STATUS=/tmp/trashcore-panel-wings-install.status
PANEL_DIR=/var/www/pterodactyl
STACK_DIR=/opt/trashcore-panel-stack
THEME_REPO="${THEME_REPO:-https://github.com/Tennor-modz/Nightshift-.git}"
THEME_COMMIT="${THEME_COMMIT:-ecf1f9b5ee52bad7a0339d025c4e994a8f41f836}"
RESUME=${1:-}
THEME_DIR=/opt/Nightshift
THEME_ARCHIVE="$THEME_DIR/release/panel.tar.gz"
BACKUP=
PANEL_MAINTENANCE=0
THEME_APPLY_STARTED=0

status(){ printf '%s | %s\n' "$(date -u +'%FT%TZ')" "$1" > "$STATUS"; chmod 644 "$STATUS"; echo "==> $1"; }
dc(){ docker compose --project-directory "$STACK_DIR" -f "$STACK_DIR/compose.yml" "$@"; }
run_panel_php(){ dc run --rm --no-deps --user 33:33 --entrypoint php panel-php "$@"; }
run_composer(){ dc run --rm --no-deps --user 33:33 --entrypoint composer panel-php "$@"; }
run_yarn(){ yarn "$@"; }

rollback_theme(){
  local failed=0 relative
  if [[ -n "$BACKUP" && -d "$BACKUP" ]]; then
    if [[ -s "$BACKUP/created-files.txt" ]]; then
      while IFS= read -r relative; do
        [[ -n "$relative" ]] || continue
        rm -rf -- "$PANEL_DIR/$relative" || failed=1
      done < "$BACKUP/created-files.txt"
    fi
    if [[ -s "$BACKUP/panel-overlay.tar" ]]; then
      tar -xf "$BACKUP/panel-overlay.tar" -C "$PANEL_DIR" || failed=1
    fi
  fi
  if (( PANEL_MAINTENANCE )); then
    run_panel_php artisan up || failed=1
    PANEL_MAINTENANCE=0
  fi
  if (( failed )); then
    echo "Nightshift rollback or Panel recovery did not finish cleanly; backup: ${BACKUP:-unavailable}"
    return 1
  fi
  return 0
}

on_exit(){
  local rc=$?
  if (( rc != 0 )); then
    if (( THEME_APPLY_STARTED )); then
      if rollback_theme; then
        status "FAILED: Nightshift apply failed; original Panel files were restored."
      else
        status "FAILED: Nightshift apply failed and automatic rollback was incomplete; inspect the backup."
      fi
    else
      status "FAILED exit=$rc line=${BASH_LINENO[0]:-unknown}"
    fi
  fi
}
trap on_exit EXIT

if [[ "$RESUME" == "--resume" ]]; then
  [[ -s "$LOG" ]] || { echo "No previous Nightshift log is available to resume."; exit 3; }
  last_event="$(grep '^==> ' "$LOG" | tail -n 1 || true)"
  last_step="$(grep '^==> ' "$LOG" | grep -v '^==> FAILED' | tail -n 1 || true)"
  if [[ "$last_step" != '==> Nightshift preflight' && "$last_step" != '==> Installing Node.js 22 for the Nightshift build' && "$last_step" != '==> Preparing the pinned Yarn 1.22.22 executable' && "$last_step" != '==> Building the Nightshift release archive' && "$last_step" != '==> Resuming Nightshift build' || "$last_event" != '==> FAILED '* ]]; then
    echo "The latest failure is not in the safe pre-application Nightshift build stage; refusing to retry."
    exit 3
  fi
else
  [[ ! -s "$LOG" ]] || { echo "A Nightshift attempt already exists; inspect status and use the safe retry only if offered."; exit 3; }
fi

mkdir -p "$(dirname "$STATUS")"
exec 9>"$LOCK"
if ! flock -n 9; then
  echo "Another Nightshift installer process is already running."
  status "FAILED: Another Nightshift installer process is already running."
  exit 8
fi
[[ $EUID -eq 0 ]] || { echo "Root privileges required."; exit 77; }
[[ "$THEME_COMMIT" =~ ^[0-9a-f]{40}$ ]] || { echo "THEME_COMMIT must be a full lowercase Git commit SHA."; exit 2; }
[[ -s "$CORE_STATUS" ]] && grep -q ' | COMPLETE:' "$CORE_STATUS" || { echo "Panel and Wings must finish successfully before Nightshift can be installed."; exit 3; }
[[ -f "$PANEL_DIR/.env" && -f "$PANEL_DIR/artisan" && -s "$STACK_DIR/compose.yml" ]] || { echo "The installed Panel and Docker service stack are incomplete."; exit 3; }

exec > >(tee -a "$LOG") 2>&1
status "$([[ "$RESUME" == "--resume" ]] && echo 'Resuming Nightshift build' || echo 'Nightshift preflight')"
exec 8>/tmp/trashcore-panel-wings-install.lock
flock -s 8
export DEBIAN_FRONTEND=noninteractive

if ! command -v git >/dev/null 2>&1; then
  apt-get update
  apt-get install -y git
fi
if ! command -v node >/dev/null 2>&1 || [[ "$(node -p 'process.versions.node.split(".")[0]')" != 22 ]] || ! command -v npm >/dev/null 2>&1; then
  status "Installing Node.js 22 for the Nightshift build"
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
command -v npm >/dev/null 2>&1 || { echo "npm is unavailable; cannot prepare the pinned Yarn package."; exit 4; }

status "Preparing the pinned Yarn 1.22.22 executable"
YARN_BIN_DIR="$(npm exec --yes --package=yarn@1.22.22 -- sh -c 'dirname "$(command -v yarn)"')"
[[ -x "$YARN_BIN_DIR/yarn" ]] || { echo "Could not locate the pinned Yarn executable."; exit 4; }
export PATH="$YARN_BIN_DIR:$PATH"
yarn --version | grep -qx '1.22.22' || { echo "The Nightshift build requires Yarn 1.22.22."; exit 4; }

status "Building the Nightshift release archive"
rm -rf "$THEME_DIR"
git init "$THEME_DIR"
git -C "$THEME_DIR" remote add origin "$THEME_REPO"
git -C "$THEME_DIR" fetch --depth 1 origin "$THEME_COMMIT"
git -C "$THEME_DIR" checkout --detach FETCH_HEAD
[[ "$(git -C "$THEME_DIR" rev-parse HEAD)" == "$THEME_COMMIT" ]]
grep -q "'version' => '1.15.2'" "$THEME_DIR/config/app.php" || { echo "Pinned Nightshift source does not match Panel 1.15.2."; exit 21; }
cd "$THEME_DIR"
run_yarn install --frozen-lockfile
mkdir -p public/assets
NODE_OPTIONS=--openssl-legacy-provider run_yarn build:production
chmod +x ./release.sh
# release.sh invokes `yarn` directly, so Yarn's pinned package bin directory must stay on PATH here.
if ! command -v zip >/dev/null 2>&1; then
  status "Installing zip for the Nightshift release build"
  apt-get update
  apt-get install -y zip
fi
env NODE_OPTIONS=--openssl-legacy-provider ./release.sh
[[ -s "$THEME_ARCHIVE" ]] || { echo "Nightshift release.sh did not create release/panel.tar.gz."; exit 21; }
tar -tzf "$THEME_ARCHIVE" >/dev/null

status "Applying Nightshift to the installed Panel"
BACKUP="/root/nightshift-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -m 700 -p "$BACKUP"
: > "$BACKUP/existing-files.txt"
: > "$BACKUP/created-files.txt"
while IFS= read -r member; do
  relative="${member#./}"
  [[ -n "$relative" && "$relative" != . ]] || continue
  case "$relative" in
    .env|storage|storage/*) continue ;;
    /*|../*|*/../*|*/..) echo "Unsafe path in Nightshift archive: $member"; exit 21 ;;
  esac
  if [[ -e "$PANEL_DIR/$relative" || -L "$PANEL_DIR/$relative" ]]; then
    printf '%s\n' "$relative" >> "$BACKUP/existing-files.txt"
  else
    printf '%s\n' "$relative" >> "$BACKUP/created-files.txt"
  fi
done < <(tar -tzf "$THEME_ARCHIVE")
if [[ -s "$BACKUP/existing-files.txt" ]]; then
  tar -C "$PANEL_DIR" -cf "$BACKUP/panel-overlay.tar" -T "$BACKUP/existing-files.txt"
fi
printf 'THEME_BACKUP=%s\n' "$BACKUP"
THEME_APPLY_STARTED=1
cd "$PANEL_DIR"
PANEL_MAINTENANCE=1
run_panel_php artisan down
tar -xzf "$THEME_ARCHIVE" -C "$PANEL_DIR" --exclude='./.env' --exclude='./storage' --exclude='./storage/*'
chown -R 33:33 "$PANEL_DIR"
run_composer install --no-dev --optimize-autoloader --no-interaction --prefer-dist
run_yarn install --frozen-lockfile
if [[ -f "$PANEL_DIR/resources/scripts/theme.ts" && -d "$PANEL_DIR/resources/scripts/theme" ]]; then
  mv "$PANEL_DIR/resources/scripts/theme.ts" "$BACKUP/theme.ts.old"
fi
status "Building production assets with Nightshift"
NODE_OPTIONS=--openssl-legacy-provider run_yarn build:production
run_panel_php artisan optimize:clear
run_panel_php artisan queue:restart
chown -R 33:33 "$PANEL_DIR"
chmod -R 755 "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache"
chmod 640 "$PANEL_DIR/.env"
run_panel_php artisan up
PANEL_MAINTENANCE=0
THEME_APPLY_STARTED=0
status "COMPLETE: Nightshift theme is installed."
echo "THEME_BACKUP=$BACKUP"
echo "PANEL_URL=https://$(grep '^APP_URL=' "$PANEL_DIR/.env" | cut -d= -f2-)"
