# TRASHCORE VPS BOT

A Telegram bot for creating and managing Boxd VPS machines and starting a Pterodactyl Panel + Wings installation. It is written for Node.js 24 and uses SQLite for users, coin balances, and VPS ownership. The welcome image is `assets/trashcore-vps-welcome.png`.

## Quick setup

1. Create a Telegram bot and copy `.env.example` to `.env`.
2. Set `BOT_TOKEN`, `BOXD_API_KEY`, and `ADMIN_IDS` in `.env`. `ADMIN_IDS` is a comma-separated list of Telegram numeric user IDs. Keep `.env` private; it is ignored by Git and excluded from the project ZIP.
3. Install and run with Node 24:

   ```bash
   npm ci
   npm test
   npm start
   ```

The SQLite database is created at `DB_PATH` (default `./database.sqlite`). It stores user balances and VPS metadata, not Boxd API keys. Set `INITIAL_CREDITS` only if you intentionally want a starting balance; it defaults to zero. Users earn 10 coins once per Africa/Nairobi calendar day. Non-admin VPS creation costs 100 bot coins; `ADMIN_IDS` users create without a bot-coin charge.

## What the bot offers

The `/start` flow keeps the welcome banner, live stats caption, and inline menu buttons together in one photo message (with a text-menu fallback if the image cannot be sent). The menu includes bot uptime, registered-user count, Boxd remaining quota, the user’s coin balance, and East Africa date/time, plus Channel and Contact Owner links. Inline buttons use Telegram’s supported `success` (green), `primary` (blue), and `danger` (red) styles where available, alongside the bot’s emoji palette.

VPS creation lets the user choose one of Boxd’s documented sizes (1 vCPU/4 GiB, 2/8 GiB, 4/16 GiB, or 8/32 GiB) and an organization-enabled Boxd region. The create request omits the `image` field so Boxd selects its documented Docker-ready default; the bot does not force `ubuntu:24.04`. A provisioning failure refunds the 100 bot coins. This bot-coin ledger is separate from Boxd billing: machines are created under the `BOXD_API_KEY` owner and any Boxd usage charges go to that Boxd account. The live quota call reads `maxVms` and `vmCount`; the display is explicitly a quota remainder, not physical inventory.

`Manage VPS` shows machine state, Boxd hostname, SSH port, region, web URL, and Boxd-reported cumulative running time when the API key can read machine usage. Boxd machine hostnames resolve to its shared HTTPS proxy, so the bot does not label that shared address as a direct VPS public IP. For a custom domain, the bot prints the exact apex A record (the Boxd proxy address used for routing) and wildcard CNAME, waits for the user to tap “DNS is set — verify”, and checks both records against public DNS before calling Boxd’s domain-binding API. Panel/Wings installation retains the existing installer’s canonical Boxd-created Panel hostname; a user domain is an additional binding.

Set `WEBAPP_URL` to the deployed public HTTPS Mini App URL to show an “Open Mini App” button in `/start`. The mobile-first dashboard is in `mini-app/` and runs as its own Node service on port 3000; Panel (port 80) and Wings (port 8080) remain separate. Its top-left menu includes Overview, Coins, My VPS, Help/commands, Owner, Channel, and Panel. VPS creation, management, coin claims, and install flows return to the existing bot menu.

The dashboard API accepts only same-origin JSON requests and validates Telegram Web App `initData` on the bot host using the bot token stored in that host’s private `.env`. Only after that HMAC check does it identify the Telegram user and run parameterized, read-only SQLite queries. A user’s balance and VPS records are queried by that verified Telegram ID; the browser never receives the bot token or Boxd API key. The Boxd key is kept in `/etc/trashcore-mini-app.env` on the dashboard host, which systemd reads for the isolated Mini App service. Keep that file root-owned with mode `0600`; never put secrets in the frontend, repository, command output, or browser storage. On this host, Node is installed inside the Boxd user's home, so the isolated unit uses a root-owned copy at `/usr/local/lib/trashcore-mini-app-runtime/node`; the service user does not need access to that home directory or to the bot's Docker group.

The live dashboard reports Boxd machine quota and enabled regions, registered bot users, global VPS totals, the Boxd bot host’s reported CPU/RAM and OS uptime, detected bot-process uptime, Nairobi date/time, and the current Telegram user’s own coin balance and VPS list. The four displayed sizes (1/4, 2/8, 4/16, 8/32 vCPU/GiB) are bot-supported configurations, not reserved machines or guaranteed stock. The quota remainder comes from the Boxd organization limit (`maxVms - vmCount`); Boxd’s documented `vmCount` is the Frankfurt count, so it must not be interpreted as physical inventory. If the bot process cannot be identified, its uptime is shown as unavailable rather than guessed. After Panel + Wings completes, machine details show “Get public IP” and “Assign allocations”. The former explains that Boxd does not provide a verified direct machine IP through this bot integration. The latter is not enabled for creation: the installer does not retain a per-panel Pterodactyl Application API token or node-ID integration. Panel allocations are separate from Boxd raw port forwards, which have a three-forward-per-machine limit.

### Mini App service configuration

Install only the `mini-app/` runtime files and run `npm ci --omit=dev` in that directory. The service environment requires `BOXD_API_KEY`, `BOT_DATA_MACHINE_ID` (the existing bot host), `BOT_DATA_REGION` (`fra` for this deployment), and `MINIAPP_ORIGIN` (`https://dash.drex-vps.boxd.sh`). Use the supplied `trashcore-mini-app.service` with the dedicated `trashcore-miniapp` account and Node 20+; the deployed runtime is Node 24. Keep the existing URL/port routing and back up the previous Mini App directory and unit before replacing them. Restart only `trashcore-mini-app.service`, not Panel, Wings, or the bot.

`GET /healthz` checks the Mini App HTTP process. `POST /api/dashboard` requires a matching `Origin`, JSON content type, and a valid, fresh `initData` string; API responses are never cached. Outside Telegram, the page intentionally shows no private live values and explains how to open the bot. The frontend refreshes live data every minute while open and uses text-only DOM rendering for user and machine strings. Run `npm test` from the project root for the complete suite, including Mini App HMAC, request validation, read-only query, and frontend contract tests. See [Telegram's Mini App validation documentation](https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app) for the authentication format.

## SSH access limitation

The bot will not fabricate a username or password. Boxd documents a one-year SSH password token created from its signed-in Mobile page, and the published SDK used here does not expose a supported method for the bot to create or share that token. The bot displays the Boxd hostname and SSH port and provides the Boxd Mobile link; an account that has access to the machine must generate the token.

## Installer and verification

The core Panel/Wings installer is `scripts/install-panel-wings.sh`. It targets a fresh Ubuntu 24.04 Boxd machine, uses the Boxd-created hostname for the primary Panel URL, and reports progress through the bot. Once Panel and Wings are running, the bot asks whether to install Nightshift; the optional theme step uses `scripts/install-nightshift.sh` and has its own progress status. Nightshift build failures can be retried only before theme application begins; failures during apply trigger an attempt to restore the original Panel files and are not automatically retried. Core setup does not depend on the theme build tools. The installer and provisioning behavior are tested with mocks and local syntax checks only; this project did not create a VM or trigger Boxd usage charges.

The installer’s Panel login password is generated for the Panel account and sent to the owner in a private Telegram message. It is not an SSH password.

## Official references

Implementation details verified against the official Boxd sources are collected in [`docs/REFERENCE.md`](docs/REFERENCE.md), including the SDK, supported resource sizes, regions, quota fields, custom-domain DNS flow, and Mobile SSH token behavior. Panel package requirements were checked against the official [Pterodactyl installation guide](https://pterodactyl.io/panel/1.0/getting_started.html).
