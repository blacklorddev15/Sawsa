const TelegramBot = require('node-telegram-bot-api');
const fs = require('node:fs');
const config = require('./config');
const db = require('./lib/db');
const { getBoxd, normaliseMachine } = require('./lib/boxd');
const { getAvailableMachineStock } = require('./lib/boxd-stock');
const { SIZES, buildCreateOptions, enabledRegions } = require('./lib/provisioning');
const { normalizeCustomDomain, domainRecords, resolveBoxdProxyIp, verifyCustomDomainDns } = require('./lib/domain');
const {
  prepareAndStart, readStatus, canResumeNightshiftBuild,
  readNightshiftStatus, isPanelWingsComplete, isNightshiftComplete,
  hasNightshiftAttempt, canRetryNightshiftBuild, prepareNightshiftAndStart
} = require('./lib/installer');
const { styleInlineKeyboard } = require('./lib/telegram-keyboard');
const { buildMainMenuKeyboard, restoreMainMenu } = require('./lib/main-menu');
const { postInstallActionRows, PUBLIC_IP_UNAVAILABLE, ALLOCATIONS_UNAVAILABLE } = require('./lib/panel-actions');
const { sendMenuLayout } = require('./lib/menu-layout');
const { joinRows, createMembershipGate } = require('./lib/membership');

if (!config.botToken) throw new Error('BOT_TOKEN is required. Copy .env.example to .env and configure it.');
if (!config.adminIds.length) throw new Error('ADMIN_IDS must contain at least one Telegram numeric user ID.');

const bot = new TelegramBot(config.botToken, { polling: true });
const sessions = new Map();
const createDrafts = new Map();
const pendingInstalls = new Map();
const domainDrafts = new Map();
const installMonitors = new Set();
const isAdmin = id => config.adminIds.includes(String(id));
const userKey = () => config.boxdApiKey;
const gate = createMembershipGate({ bot, targets: config.requiredChats, isAdmin });
gate.validateSetup();

// Every slash command goes through the membership gate (private chats only; admins bypass).
const registerOnText = bot.onText.bind(bot);
bot.onText = (regexp, callback) => registerOnText(regexp, async (msg, match) => {
  if (msg.chat && msg.chat.type === 'private' && msg.from && !(await passGate(msg.from.id, msg.chat.id))) return;
  return callback(msg, match);
});

function todayEAT() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: config.timezone, year: 'numeric', month: '2-digit', day: '2-digit'
  }).format(new Date());
}
function dateTimeEAT() {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: config.timezone, weekday: 'short', day: '2-digit', month: 'short',
    year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false
  }).format(new Date());
}
function privateOnly(msg) { return Boolean(msg.chat && msg.chat.type === 'private'); }
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function safeError(err) {
  return String(err && err.message || 'Unknown error')
    .replace(/bxd_[A-Za-z0-9_-]+/g, '[redacted]')
    .replace(/\b\d{5,}:[A-Za-z0-9_-]{20,}\b/g, '[redacted]')
    .replace(/(api[_ -]?key|token|password)\s*[:=]\s*[^\s;,]+/gi, '$1=[redacted]')
    .slice(0, 240);
}
function formatDuration(seconds) {
  const n = Math.max(0, Math.floor(Number(seconds) || 0));
  const days = Math.floor(n / 86400);
  const hours = Math.floor((n % 86400) / 3600);
  const minutes = Math.floor((n % 3600) / 60);
  const secs = n % 60;
  return [days ? `${days}d` : '', `${hours}h`, `${minutes}m`, `${secs}s`].filter(Boolean).join(' ');
}
const TITLE = '┏❐  ⌜ 𝐓𝐑𝐀𝐒𝐇𝐂𝐎𝐑𝐄 ⌟ ❐';
const DIV = '──────────────';
// Invisible padding (Braille blanks) on the footer line makes Telegram render the bubble at its
// wide size, so the inline keyboard no longer sticks out past the message. Tune MENU_WIDTH_PAD:
// raise it if buttons still overhang, lower it if a blank line appears under the footer.
const MENU_WIDTH_PAD = '\u2800'.repeat(14);
const FOOT = `© <b>TRASHCORE VPS BOT</b>${MENU_WIDTH_PAD}`;
const head = sub => `${TITLE}\n┃⭔ <b>${sub}</b>`;
const item = text => `┃⭔ ${text}`;
const line = (label, value) => `┃⭔ <b>${esc(label)}:</b> ${value}`;
const section = (title, lines) => [`❐ <b>${esc(title)}</b>`, ...lines].join('\n');
const frame = (sub, sections, tagline) =>
  `${head(sub)}${tagline ? `\n┃⭔ ${tagline}` : ''}\n<blockquote>${sections.join(`\n${DIV}\n`)}</blockquote>\n${FOOT}`;
const note = (sub, ...lines) => frame(sub, [section('STATUS', lines.map(value => item(esc(value))))]);
const BACK_ROW = [{ text: '↩️ Back to menu', callback_data: 'menu_home' }];
const cbOk = (prefix, id) => `${prefix}:${id}`.length <= 64;

let stockCache = { at: 0, text: '' };
async function stockLine() {
  if (!config.boxdApiKey) return 'Unavailable — configure BOXD_API_KEY';
  if (stockCache.text && Date.now() - stockCache.at < 60000) return stockCache.text;
  let boxd;
  try {
    boxd = await getBoxd(config.boxdApiKey);
    const { available, used, limit } = await getAvailableMachineStock(boxd);
    stockCache = {
      at: Date.now(),
      text: `${available} remaining quota (${used}/${limit}; Frankfurt count)`
    };
  } catch {
    stockCache = { at: Date.now(), text: 'Unavailable — check Boxd key permissions' };
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
  return stockCache.text;
}
function userCoins(userId) {
  const user = db.getUser(userId);
  return isAdmin(userId) ? 'Unlimited (Admin)' : `${user ? user.credits : config.initialCredits} coins`;
}
async function statsText(userId) {
  const stats = db.stats();
  const stock = await stockLine();
  return frame('LIVE STATS', [
    section('BOT', [
      line('Uptime', esc(formatDuration(process.uptime()))),
      line('Users', stats.users),
      line('Active VPS', stats.activeVps),
      line('VPS quota remaining', esc(stock))
    ]),
    section('YOUR ACCOUNT', [line('Coin balance', esc(userCoins(userId)))]),
    section('TIME', [line('Date', `${esc(dateTimeEAT())} EAT`)])
  ]);
}
async function startText(userId) {
  const stats = db.stats();
  const stock = await stockLine();
  return frame('TRASHCORE VPS BOT', [
    section('WELCOME', [item('Create and manage Boxd VPS machines.'), item('Install Pterodactyl Panel + Wings.')]),
    section('LIVE STATS', [
      line('Bot uptime', esc(formatDuration(process.uptime()))),
      line('Users', stats.users),
      line('VPS quota remaining', esc(stock)),
      line('Your coin balance', esc(userCoins(userId))),
      line('Date', `${esc(dateTimeEAT())} EAT`)
    ])
  ], '<i>Create • Install • Manage</i>');
}

function gateText(results = []) {
  const mark = target => {
    const found = results.find(result => result.target === target);
    if (!found) return '▫️ not checked';
    return found.state === 'joined' ? '✅ joined' : found.state === 'error' ? '⚠️ cannot verify' : '❌ not joined';
  };
  const notes = results.some(result => result.state === 'error')
    ? [item('A chat could not be checked. Please tell the bot owner.')]
    : [item('Tap Join, then tap Verify.')];
  return frame('JOIN REQUIRED', [
    section('MEMBERSHIP', [item('Join the chats below to use this bot.'), ...gate.targets.map(target => line(target.label, mark(target)))]),
    section('NEXT', notes)
  ]);
}
const gateRows = () => [...joinRows(gate.targets), [{ text: '✅ Verify', callback_data: 'verify_join' }]];
async function passGate(userId, chatId) {
  const result = await gate.check(userId);
  if (result.ok) return true;
  await bot.sendMessage(chatId, gateText(result.results), {
    parse_mode: 'HTML', reply_markup: { inline_keyboard: styleInlineKeyboard(gateRows()) }
  });
  return false;
}

let menuPhotoId = null;
async function sendMenu(chatId, userId) {
  const caption = await startText(userId);
  const keyboard = { inline_keyboard: buildMainMenuKeyboard(config.webAppUrl, isAdmin(userId)) };
  const photoSources = fs.existsSync(config.menuImage)
    ? [menuPhotoId, config.menuImage].filter(Boolean)
    : [];
  const result = await sendMenuLayout(bot, chatId, photoSources, caption, keyboard, (err, source) => {
    if (source === menuPhotoId) menuPhotoId = null;
    console.error('[welcome image failed]', safeError(err));
  });
  const photo = result.photoMessage && result.photoMessage.photo && result.photoMessage.photo.at(-1);
  if (photo && photo.file_id) menuPhotoId = photo.file_id;
  return result.menuMessage;
}
async function showScreen(message, text, rows = []) {
  const keyboardRows = styleInlineKeyboard(rows);
  const options = {
    chat_id: message.chat.id,
    message_id: message.message_id,
    reply_markup: { inline_keyboard: keyboardRows }
  };
  try {
    if (message.photo) return await bot.editMessageCaption(text, { ...options, parse_mode: 'HTML' });
    return await bot.editMessageText(text, { ...options, parse_mode: 'HTML' });
  } catch (err) {
    if (/message is not modified/i.test(String(err && err.message))) return;
    console.error('[screen edit failed]', safeError(err));
    return bot.sendMessage(message.chat.id, text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboardRows } });
  }
}
function register(msg) { db.registerUser(msg.from.id, msg.from.username || null); }

async function enabledBoxdRegions() {
  let boxd;
  try {
    boxd = await getBoxd(config.boxdApiKey);
    return enabledRegions(await boxd.orgs.regions());
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
}
async function showCreateWizard(message, userId) {
  if (!config.boxdApiKey) {
    return showScreen(message, note('CREATE VPS', 'The bot owner must configure BOXD_API_KEY in .env before VPS creation is enabled.'), [BACK_ROW]);
  }
  const user = db.getUser(userId);
  if (!isAdmin(userId) && (!user || user.credits < config.vpsCost)) {
    return showScreen(message, frame('CREATE VPS', [section('COINS', [
      line('VPS cost', `${config.vpsCost} coins`),
      line('Your balance', `${user ? user.credits : 0} coins`),
      item('Claim 10 coins once per Nairobi calendar day.')
    ])]), [[{ text: '🪙 Claim Daily 10', callback_data: 'menu_claim' }], BACK_ROW]);
  }
  createDrafts.set(String(userId), { stage: 'size' });
  const rows = Object.entries(SIZES).map(([key, size]) => [{ text: `🖥 ${size.label}`, callback_data: `create_size:${key}` }]);
  return showScreen(message, frame('CREATE VPS', [
    section('CHOOSE SIZE', [item('These are the four machine sizes documented by Boxd.')]),
    section('BILLING', [line('Cost', isAdmin(userId) ? 'FREE to you (Admin)' : `${config.vpsCost} coins`), item('Boxd usage is billed to the bot owner’s Boxd account.')])
  ]), [...rows, [{ text: 'Cancel', callback_data: 'create_cancel' }], BACK_ROW]);
}
async function showRegionPicker(message, userId) {
  const draft = createDrafts.get(String(userId));
  if (!draft || !draft.sizeKey) return showCreateWizard(message, userId);
  try {
    const regions = await enabledBoxdRegions();
    if (!regions.length) return showScreen(message, note('CREATE VPS', 'Boxd did not report any enabled regions for this account.'), [BACK_ROW]);
    draft.regions = regions;
    draft.stage = 'region';
    const rows = regions.map(region => [{ text: `🌐 ${region.name} (${region.id})`, callback_data: `create_region:${region.id}` }]);
    return showScreen(message, frame('CREATE VPS', [section('CHOOSE REGION', [
      item('Only regions enabled for the connected Boxd organization are shown.'),
      line('Size', esc(SIZES[draft.sizeKey].label))
    ])]), [...rows, [{ text: 'Cancel', callback_data: 'create_cancel' }], BACK_ROW]);
  } catch (err) {
    return showScreen(message, note('CREATE VPS', 'Could not read enabled Boxd regions.', safeError(err)), [BACK_ROW]);
  }
}
function showCreateConfirmation(message, userId) {
  const draft = createDrafts.get(String(userId));
  if (!draft || !draft.sizeKey || !draft.region) return showCreateWizard(message, userId);
  draft.stage = 'confirm';
  const size = SIZES[draft.sizeKey];
  const region = (draft.regions || []).find(item => item.id === draft.region);
  return showScreen(message, frame('CONFIRM VPS', [
    section('MACHINE', [
      line('CPU / RAM', esc(size.label)),
      line('Region', `${esc(region ? region.name : draft.region)} (${esc(draft.region)})`),
      line('Image', 'Boxd default (Docker-ready)'),
      line('SSH', 'Enabled by Boxd')
    ]),
    section('COST', [
      line('Bot coins', isAdmin(userId) ? '0 (Admin)' : `${config.vpsCost} coins`),
      item('The Boxd account owner may incur Boxd machine usage charges.')
    ])
  ]), [[{ text: '✅ Confirm creation', callback_data: 'create_confirm' }, { text: 'Cancel', callback_data: 'create_cancel' }], BACK_ROW]);
}

function machineSections(machine, extra = []) {
  return [
    section('MACHINE', [
      line('Name', `<code>${esc(machine.name)}</code>`),
      line('ID', `<code>${esc(machine.id)}</code>`),
      line('Status', esc(machine.status || 'unknown')),
      line('Region', esc(machine.region || 'fra'))
    ]),
    section('RESOURCES', [
      line('CPU', `${Number(machine.vcpu || 0) || 'Not reported'} vCPU`),
      line('Memory', machine.memoryBytes ? `${(machine.memoryBytes / 1024 ** 3).toFixed(1)} GiB` : 'Not reported'),
      ...extra
    ]),
    section('ACCESS DETAILS', [
      line('Boxd host', machine.domain ? `<code>${esc(machine.domain)}</code>` : 'Not reported'),
      line('Direct public IP', 'Not exposed by Boxd (hostname uses shared proxy)'),
      line('SSH port', machine.sshPort || 'Not reported'),
      line('Web URL', machine.url ? `<a href="${esc(machine.url)}">${esc(machine.url)}</a>` : 'Not reported'),
      line('Custom domain', machine.customDomain ? esc(machine.customDomain) : 'None bound')
    ]),
    section('SSH TOKEN NOTE', [
      item('Boxd issues one-year SSH passwords from its signed-in Mobile page. The published SDK cannot create or send that token, so this bot does not invent a username or password.'),
      item('Only a Boxd account that can access this machine can generate its token.')
    ])
  ];
}
function machineText(row, runningTime = 'Checking…') {
  return frame('VPS DETAILS', machineSections({
    id: row.id, name: row.name, status: row.status, region: row.region,
    vcpu: row.vcpu, memoryBytes: row.memory_bytes, domain: row.domain,
    sshPort: row.ssh_port, url: row.url,
    customDomain: row.custom_domain
  }, [line('Running time', esc(runningTime))]));
}
function machineRows(id, name, customDomain, retryAvailable = false, themeAvailable = false, themeRetryAvailable = false, panelReady = false) {
  const mobileUrl = 'https://app.boxd.sh/mobile';
  return [
    [{ text: '🔄 Refresh status', callback_data: `vps_refresh:${id}` }],
    ...(retryAvailable ? [[{ text: '🔁 Retry installation', callback_data: `vps_iretry:${id}` }]] : []),
    ...(themeRetryAvailable ? [[{ text: '🔁 Retry Nightshift', callback_data: `vps_nretry:${id}` }]] : []),
    ...(themeAvailable ? [[{ text: '🌙 Install Nightshift', callback_data: `vps_nightshift:${id}` }]] : []),
    [{ text: '🟣 Install Panel + Wings', callback_data: `vps_install:${id}` }, { text: '🟠 Install progress', callback_data: `vps_istatus:${id}` }],
    ...postInstallActionRows(id, panelReady),
    ...(customDomain ? [[{ text: '🌐 Custom domain status', callback_data: `domain_status:${id}` }]] : []),
    [{ text: '📲 Boxd Mobile SSH', url: mobileUrl }],
    [{ text: '📋 My VPS', callback_data: 'menu_vps' }, { text: '↩️ Menu', callback_data: 'menu_home' }]
  ];
}
async function runningTimeLabel(row) {
  if (!config.boxdApiKey || !row.created_at) return 'Not available';
  const createdAt = new Date(row.created_at).getTime();
  if (!Number.isFinite(createdAt)) return 'Not available';
  const maxWindow = 366 * 24 * 60 * 60 * 1000;
  const since = new Date(Math.max(createdAt, Date.now() - maxWindow));
  let boxd;
  try {
    boxd = await getBoxd(config.boxdApiKey, row.region || 'fra');
    const usage = await boxd.machines.usage(row.id, { since, until: new Date() });
    const seconds = Number(usage && usage.seconds && usage.seconds.running);
    if (!Number.isFinite(seconds)) return 'Not reported';
    const suffix = createdAt < Date.now() - maxWindow ? ' cumulative (last 366 days)' : ' cumulative since creation';
    return `${formatDuration(seconds)}${suffix}`;
  } catch {
    return 'Not available to this Boxd key';
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
}
async function screenMachine(message, userId, id) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('VPS DETAILS', 'Machine not found.'), [BACK_ROW]);
  const uptime = await runningTimeLabel(row);
  let retryAvailable = false;
  let panelReady = false;
  let themeAvailable = false;
  let themeRetryAvailable = false;
  if (config.boxdApiKey) {
    try {
      const output = await readStatus(config.boxdApiKey, row.id, row.region);
      panelReady = isPanelWingsComplete(output);
      retryAvailable = canResumeNightshiftBuild(output);
      if (isPanelWingsComplete(output) && !/THEME_BACKUP=/.test(output)) {
        const themeOutput = await readNightshiftStatus(config.boxdApiKey, row.id, row.region);
        themeRetryAvailable = canRetryNightshiftBuild(themeOutput);
        themeAvailable = !isNightshiftComplete(themeOutput) && !hasNightshiftAttempt(themeOutput) && !themeRetryAvailable;
      }
    } catch {}
  }
  return showScreen(message, machineText(row, uptime), machineRows(row.id, row.name, row.custom_domain, retryAvailable, themeAvailable, themeRetryAvailable, panelReady));
}
async function screenVpsList(message, userId) {
  const rows = db.listMachines(userId);
  if (!rows.length) return showScreen(message, note('MY VPS', 'You have no VPS yet.', 'Create one first.'), [[{ text: '🟢 Create VPS', callback_data: 'menu_create' }], BACK_ROW]);
  const shown = rows.slice(0, 8);
  const text = frame('MANAGE VPS', [
    section(`YOUR VPS (${rows.length})`, shown.map((machine, i) => item(`${i + 1}. ${esc(machine.name)} — ${esc(machine.status || 'unknown')} (${esc(machine.region || 'fra')})`))),
    section('UPTIME', [item('Open a machine to see Boxd-reported cumulative running time; it is not an uninterrupted boot timer.')])
  ]);
  const buttons = shown.filter(machine => cbOk('vps_view', machine.id))
    .map((machine, i) => [{ text: `🖥 ${i + 1}. ${machine.name}`.slice(0, 40), callback_data: `vps_view:${machine.id}` }]);
  return showScreen(message, text, [...buttons, BACK_ROW]);
}
async function machinePicker(message, userId, action, title) {
  const rows = db.listMachines(userId);
  if (!rows.length) return showScreen(message, note('SELECT VPS', 'No VPS found. Create one first.'), [[{ text: '🟢 Create VPS', callback_data: 'menu_create' }], BACK_ROW]);
  if (rows.length === 1) return runMachineAction(message, userId, action, rows[0].id);
  const buttons = rows.slice(0, 8).filter(row => cbOk(action, row.id))
    .map((row, i) => [{ text: `${i + 1}. ${row.name}`.slice(0, 40), callback_data: `${action}:${row.id}` }]);
  return showScreen(message, note('SELECT VPS', title), [...buttons, BACK_ROW]);
}
async function refreshMachine(message, userId, id) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('VPS DETAILS', 'Machine not found.'), [BACK_ROW]);
  if (!config.boxdApiKey) return showScreen(message, note('VPS DETAILS', 'BOXD_API_KEY is not configured.'), [BACK_ROW]);
  let boxd;
  try {
    boxd = await getBoxd(config.boxdApiKey, row.region || 'fra');
    const fresh = await boxd.machines.get(row.id);
    const normalized = normaliseMachine({ ...fresh, region: fresh.region || row.region || 'fra' });
    db.updateMachine(normalized.status, normalized.domain, normalized.url, normalized.sshPort,
      normalized.vcpu, normalized.memoryBytes, row.id, userId, normalized.region, normalized.image, null);
    return screenMachine(message, userId, row.id);
  } catch (err) {
    return showScreen(message, note('VPS DETAILS', 'Could not refresh machine status.', safeError(err)),
      [[{ text: 'Retry', callback_data: `vps_refresh:${row.id}` }], BACK_ROW]);
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
}

function installPrompt(userId, row) {
  pendingInstalls.set(String(userId), row.id);
  return {
    text: frame('INSTALL PANEL + WINGS', [
      section('TARGET', [line('VPS', `<code>${esc(row.name)}</code>`), line('Region', esc(row.region || 'fra'))]),
      section('INSTALL', [
        line('Panel', 'Pterodactyl 1.15.2'),
        line('Wings', `wings subdomain of ${esc(row.domain || 'the Boxd hostname')}`),
        line('OS', 'Ubuntu 24.04'), line('Timezone', 'Africa/Nairobi'),
        line('Boxd bot protection', 'Off for this VPS only; Pterodactyl authentication stays enabled'),
        item('Nightshift is optional and will be offered after Panel + Wings finish.')
      ]),
      section('IMPORTANT', [
        item('Use only on a fresh machine; existing Panel files will not be overwritten.'),
        item('The installer keeps the canonical Boxd-created hostname as the primary Panel URL. A verified custom domain is an additional Boxd binding.'),
        item('Confirming starts changes on this VPS and Boxd API proxy/port setup.')
      ])
    ]),
    rows: [[{ text: '✅ Start installation', callback_data: 'install_confirm' }, { text: 'Cancel', callback_data: 'install_cancel' }], BACK_ROW]
  };
}
async function beginDomainSetup(message, userId, row) {
  if (row.custom_domain) {
    const prompt = installPrompt(userId, row);
    return showScreen(message, prompt.text, prompt.rows);
  }
  sessions.set(String(userId), { action: 'custom_domain', machineId: row.id, menu: message });
  return showScreen(message, frame('CUSTOM DOMAIN', [section('ENTER DOMAIN', [
    item('Send the hostname you control, for example panel.example.com.'),
    item('The bot will show an exact A record and wildcard CNAME, then wait for your DNS-is-set action and verify both before Boxd binding.'),
    item('You can choose to continue with the canonical Boxd hostname instead.')
  ])]), [[{ text: 'Use Boxd hostname only', callback_data: `domain_skip:${row.id}` }], BACK_ROW]);
}
function domainSetupText(domain, records, region) {
  return frame('SET DNS RECORDS', [
    section('DOMAIN', [line('Hostname', `<code>${esc(domain)}</code>`), line('Region', esc(region))]),
    section('REQUIRED DNS', records.map(record => [
      line('Type', `<code>${esc(record.type)}</code>`),
      line('Name / Host', `<code>${esc(record.host)}</code>`),
      line('Value / Target', `<code>${esc(record.value)}</code>`)
    ].join('\n'))),
    section('NEXT', [
      item('Add both records exactly, wait for public DNS to resolve, then tap “DNS is set — verify”.'),
      item('The A-record address is Boxd’s shared HTTPS proxy IP for hostname routing, not a direct machine IP.'),
      item('If your DNS panel appends the zone automatically, enter the relative host labels rather than duplicating the domain.'),
      item('The Panel will still use its canonical Boxd hostname; this custom name is an additional binding.')
    ])
  ]);
}
async function processDomainInput(msg, session) {
  const userId = String(msg.from.id);
  const menu = session.menu;
  const raw = String(msg.text || '').trim();
  let domain;
  try { domain = normalizeCustomDomain(raw); }
  catch (err) {
    sessions.set(userId, session);
    return showScreen(menu, note('CUSTOM DOMAIN', safeError(err), 'Send a hostname such as panel.example.com.'),
      [[{ text: 'Use Boxd hostname only', callback_data: `domain_skip:${session.machineId}` }], BACK_ROW]);
  }
  const row = db.getMachine(session.machineId, userId);
  if (!row) return showScreen(menu, note('CUSTOM DOMAIN', 'Machine not found.'), [BACK_ROW]);
  let boxd;
  try {
    boxd = await getBoxd(config.boxdApiKey, row.region || 'fra');
    const fresh = await boxd.machines.get(row.id);
    const machine = normaliseMachine({ ...fresh, region: fresh.region || row.region || 'fra' });
    const ip = await resolveBoxdProxyIp(machine);
    const records = domainRecords(domain, ip, machine.domain);
    domainDrafts.set(userId, { machineId: row.id, domain, expectedIp: ip, expectedTarget: machine.domain, region: machine.region });
    return showScreen(menu, domainSetupText(domain, records, machine.region), [
      [{ text: '✅ DNS is set — verify', callback_data: 'domain_verify' }],
      [{ text: 'Cancel domain setup', callback_data: 'domain_cancel' }], BACK_ROW
    ]);
  } catch (err) {
    sessions.set(userId, session);
    return showScreen(menu, note('CUSTOM DOMAIN', 'Could not prepare the DNS record values.', safeError(err)),
      [[{ text: 'Use Boxd hostname only', callback_data: `domain_skip:${row.id}` }], BACK_ROW]);
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
}
async function verifyAndBindDomain(message, userId) {
  const draft = domainDrafts.get(String(userId));
  if (!draft) return showScreen(message, note('CUSTOM DOMAIN', 'DNS setup expired. Start again from Install Panel.'), [BACK_ROW]);
  const row = db.getMachine(draft.machineId, userId);
  if (!row) return showScreen(message, note('CUSTOM DOMAIN', 'Machine not found.'), [BACK_ROW]);
  let boxd;
  try {
    boxd = await getBoxd(config.boxdApiKey, draft.region);
    const fresh = await boxd.machines.get(row.id);
    const machine = normaliseMachine({ ...fresh, region: fresh.region || draft.region });
    const currentIp = await resolveBoxdProxyIp(machine);
    const result = await verifyCustomDomainDns(draft.domain, currentIp, machine.domain);
    if (!result.ok) {
      const a = result.aMatch ? 'MATCH' : `NOT MATCHED (${result.observedA.join(', ') || 'no A record'})`;
      const cname = result.cnameMatch ? 'MATCH' : `NOT MATCHED (${result.observedCname.join(', ') || 'no wildcard CNAME'})`;
      const records = domainRecords(draft.domain, currentIp, machine.domain);
      return showScreen(message, frame('DNS NOT READY', [
        section('CHECK RESULTS', [line('A record', esc(a)), line('Wildcard CNAME', esc(cname))]),
        section('EXPECTED', records.map(record => line(record.type, `<code>${esc(record.host)} → ${esc(record.value)}</code>`))),
        section('ACTION', [item('Correct the DNS at your provider, wait for propagation, then check again. Boxd has not been asked to bind this domain.')])
      ]), [[{ text: '🔄 Check DNS again', callback_data: 'domain_verify' }], BACK_ROW]);
    }
    const existing = await boxd.domains.list({ region: draft.region });
    let binding = existing.find(item => item.domain.toLowerCase() === draft.domain.toLowerCase());
    if (binding && binding.machineId !== row.id) throw new Error('This domain is already bound to another machine in the Boxd account.');
    if (!binding) binding = await boxd.domains.create({ domain: draft.domain, machine: row.id, region: draft.region });
    db.setCustomDomain(draft.domain, row.id, userId);
    domainDrafts.delete(String(userId));
    return showScreen(message, frame('DOMAIN VERIFIED', [
      section('DNS MATCHED', [line('A record', 'Verified'), line('Wildcard CNAME', 'Verified')]),
      section('BOXD BINDING', [line('Domain', `<code>${esc(draft.domain)}</code>`), line('Status', esc(binding.status || 'pending')), item('Boxd now handles domain verification and certificate activation; this can take a little time.')]),
      section('PANEL URL', [item('The primary Panel URL remains the canonical Boxd-created hostname; the custom hostname is an additional domain binding.')])
    ]), [[{ text: 'Continue to install Panel + Wings', callback_data: `install_begin:${row.id}` }], BACK_ROW]);
  } catch (err) {
    return showScreen(message, note('CUSTOM DOMAIN', 'Could not verify or bind the custom domain.', safeError(err), 'DNS must match before Boxd receives the binding request.'),
      [[{ text: '🔄 Check DNS again', callback_data: 'domain_verify' }], BACK_ROW]);
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
}
async function checkCustomDomainStatus(message, userId, row) {
  if (!row.custom_domain) return showScreen(message, note('DOMAIN STATUS', 'No custom domain is saved for this VPS.'), [BACK_ROW]);
  let boxd;
  try {
    boxd = await getBoxd(config.boxdApiKey, row.region || 'fra');
    const list = await boxd.domains.list({ region: row.region || 'fra' });
    const found = list.find(domain => domain.domain.toLowerCase() === row.custom_domain.toLowerCase());
    const state = found ? found.status : 'not found in Boxd domain bindings';
    return showScreen(message, frame('DOMAIN STATUS', [section('BOXD', [
      line('Domain', `<code>${esc(row.custom_domain)}</code>`),
      line('Status', esc(state)),
      ...(found && found.lastError ? [line('Last error', esc(found.lastError))] : [])
    ])]), [[{ text: '🔄 Refresh domain status', callback_data: `domain_status:${row.id}` }], BACK_ROW]);
  } catch (err) {
    return showScreen(message, note('DOMAIN STATUS', 'Could not refresh Boxd domain status.', safeError(err)), [BACK_ROW]);
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
}

function nightshiftPromptText(row) {
  return frame('PANEL + WINGS READY', [
    section('CORE INSTALL COMPLETE', [
      line('VPS', `<code>${esc(row.name)}</code>`),
      item('Pterodactyl Panel and Wings are installed and running.')
    ]),
    section('OPTIONAL THEME', [
      item('Would you like to install the Nightshift theme on this Panel?'),
      item('You can skip now and install it later from VPS details or Install Status.')
    ])
  ]);
}
function nightshiftPromptRows(id) {
  return [
    [{ text: '🌙 Install Nightshift', callback_data: `vps_nightshift:${id}` }, { text: '⏭️ Skip for now', callback_data: `vps_nightshift_skip:${id}` }],
    [{ text: '🟠 Install Status', callback_data: `vps_istatus:${id}` }], BACK_ROW
  ];
}
function installationProgress(machineName, output) {
  const raw = String(output || '').replace(/```/g, '').trim();
  const [statusBlock = '', logBlock = ''] = raw.split(/--- LOG TAIL ---/);
  const statusLine = statusBlock.split(/\r?\n/).map(line => line.trim()).filter(Boolean).at(-1) || '';
  const match = statusLine.match(/^\d{4}-\d{2}-\d{2}T\S+\s+\|\s*(.+)$/);
  const stage = match ? match[1] : /status not available/i.test(statusLine)
    ? 'Waiting for the installer process to initialize…'
    : statusLine || 'Waiting for the installer to report its first step…';
  const failed = /^FAILED\b/i.test(stage);
  const complete = /^COMPLETE:/i.test(stage);
  const recent = logBlock.split(/\r?\n/).map(line => line.trim()).filter(Boolean)
    .filter(line => !/^No installer log yet\.?$/i.test(line)).slice(-3);
  const sections = [section('VPS', [line('Name', `<code>${esc(machineName)}</code>`)]), section('CURRENT STEP', [item(esc(stage))])];
  if (recent.length) sections.push(section('RECENT OUTPUT', recent.map(entry => item(`<code>${esc(entry.slice(0, 140))}</code>`))));
  return { text: frame(complete ? 'INSTALL COMPLETE' : failed ? 'INSTALL FAILED' : 'INSTALL IN PROGRESS', sections), terminal: complete || failed, complete, failed };
}
function installationKeyboard(row, output, progress) {
  if (progress.complete && !/THEME_BACKUP=/.test(String(output || ''))) return nightshiftPromptRows(row.id);
  if (progress.failed && canResumeNightshiftBuild(output)) {
    return [[{ text: '🔁 Retry installation', callback_data: `vps_iretry:${row.id}` }],
      [{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW];
  }
  return [[{ text: '🔄 Refresh progress', callback_data: `vps_istatus:${row.id}` }], BACK_ROW];
}
function nightshiftInstallationProgress(machineName, output) {
  const raw = String(output || '').replace(/```/g, '').trim();
  const [statusBlock = '', logBlock = ''] = raw.split(/--- LOG TAIL ---/);
  const statusLine = statusBlock.split(/\r?\n/).map(line => line.trim()).filter(Boolean).at(-1) || '';
  const match = statusLine.match(/^\d{4}-\d{2}-\d{2}T\S+\s+\|\s*(.+)$/);
  const stage = match ? match[1] : /status not available/i.test(statusLine)
    ? 'Waiting for the Nightshift installer to initialize…'
    : statusLine || 'Waiting for the Nightshift installer to report its first step…';
  const failed = /^FAILED\b/i.test(stage);
  const complete = /^COMPLETE:/i.test(stage);
  const recent = logBlock.split(/\r?\n/).map(line => line.trim()).filter(Boolean)
    .filter(line => !/^No Nightshift installer log yet\.?$/i.test(line)).slice(-3);
  const sections = [section('VPS', [line('Name', `<code>${esc(machineName)}</code>`)]), section('CURRENT STEP', [item(esc(stage))])];
  if (recent.length) sections.push(section('RECENT OUTPUT', recent.map(entry => item(`<code>${esc(entry.slice(0, 140))}</code>`))));
  return { text: frame(complete ? 'NIGHTSHIFT INSTALLED' : failed ? 'NIGHTSHIFT FAILED' : 'NIGHTSHIFT IN PROGRESS', sections), terminal: complete || failed, complete, failed };
}
function nightshiftKeyboard(row, output, progress) {
  if (progress.failed && canRetryNightshiftBuild(output)) {
    return [[{ text: '🔁 Retry Nightshift', callback_data: `vps_nretry:${row.id}` }],
      [{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW];
  }
  return [[{ text: '🔄 Refresh progress', callback_data: `vps_istatus:${row.id}` }], BACK_ROW];
}
async function monitorInstallation(chatId, userId, row) {
  const monitorId = `${chatId}:${row.id}`;
  if (installMonitors.has(monitorId)) return;
  installMonitors.add(monitorId);
  let sent;
  try {
    let output = 'Installer status not available yet.';
    const first = installationProgress(row.name, output);
    sent = await bot.sendMessage(chatId, first.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: styleInlineKeyboard(installationKeyboard(row, output, first)) } });
    let previous = first.text;
    for (let attempt = 0; attempt < 180; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 20000));
      try { output = await readStatus(config.boxdApiKey, row.id, row.region); }
      catch (err) { output = `Installer status not available yet.\n${safeError(err)}`; }
      const progress = installationProgress(row.name, output);
      const displayText = progress.complete && !/THEME_BACKUP=/.test(String(output || ''))
        ? nightshiftPromptText(row) : progress.text;
      if (displayText !== previous) {
        try {
          await bot.editMessageText(displayText, {
            chat_id: chatId, message_id: sent.message_id,
            parse_mode: 'HTML', reply_markup: { inline_keyboard: styleInlineKeyboard(installationKeyboard(row, output, progress)) }
          });
          previous = displayText;
        } catch {}
      }
      if (progress.terminal) break;
    }
  } catch (err) {
    console.error('[install monitor failed]', safeError(err));
  } finally {
    installMonitors.delete(monitorId);
  }
}
async function monitorNightshiftInstallation(chatId, userId, row) {
  const monitorId = `${chatId}:${row.id}:nightshift`;
  if (installMonitors.has(monitorId)) return;
  installMonitors.add(monitorId);
  let sent;
  try {
    let output = 'Nightshift installer status not available yet.';
    const first = nightshiftInstallationProgress(row.name, output);
    sent = await bot.sendMessage(chatId, first.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: styleInlineKeyboard(nightshiftKeyboard(row, output, first)) } });
    let previous = first.text;
    for (let attempt = 0; attempt < 180; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 20000));
      try { output = await readNightshiftStatus(config.boxdApiKey, row.id, row.region); }
      catch (err) { output = `Nightshift installer status not available yet.\n${safeError(err)}`; }
      const progress = nightshiftInstallationProgress(row.name, output);
      if (progress.text !== previous) {
        try {
          await bot.editMessageText(progress.text, {
            chat_id: chatId, message_id: sent.message_id,
            parse_mode: 'HTML', reply_markup: { inline_keyboard: styleInlineKeyboard(nightshiftKeyboard(row, output, progress)) }
          });
          previous = progress.text;
        } catch {}
      }
      if (progress.terminal) break;
    }
  } catch (err) {
    console.error('[Nightshift monitor failed]', safeError(err));
  } finally {
    installMonitors.delete(monitorId);
  }
}
async function screenInstallStatus(message, userId, id) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('INSTALL STATUS', 'Machine not found.'), [BACK_ROW]);
  if (!config.boxdApiKey) return showScreen(message, note('INSTALL STATUS', 'BOXD_API_KEY is not configured.'), [BACK_ROW]);
  try {
    const output = String(await readStatus(config.boxdApiKey, row.id, row.region)).replace(/```/g, '').trim();
    const recent = output.split('\n').map(value => value.trim()).filter(Boolean).slice(-9).map(value => value.slice(0, 90));
    const retryAvailable = canResumeNightshiftBuild(output);
    const coreComplete = isPanelWingsComplete(output);
    let rows = [];
    const sections = [
      section('VPS', [line('Name', esc(row.name)), line('Region', esc(row.region || 'fra'))]),
      section('PANEL + WINGS', (recent.length ? recent : ['No output yet.']).map(value => item(esc(value))))
    ];
    if (coreComplete) {
      if (/THEME_BACKUP=/.test(output)) {
        sections.push(section('NIGHTSHIFT', [item('Already installed by an earlier combined Panel/Wings installer.') ]));
      } else {
        const themeOutput = await readNightshiftStatus(config.boxdApiKey, row.id, row.region);
        const themeLines = themeOutput.split('\n').map(value => value.trim()).filter(Boolean).slice(-6).map(value => value.slice(0, 90));
        const themeComplete = isNightshiftComplete(themeOutput);
        const themeRetryAvailable = canRetryNightshiftBuild(themeOutput);
        const themeAttempt = hasNightshiftAttempt(themeOutput);
        sections.push(section('NIGHTSHIFT', themeComplete
          ? [item('Nightshift theme is installed.')]
          : (themeLines.length ? themeLines : ['Not installed yet.']).map(value => item(esc(value)))));
        if (themeComplete) rows = [[{ text: '🔄 Refresh', callback_data: `vps_istatus:${row.id}` }]];
        else if (themeRetryAvailable) rows = [[{ text: '🔁 Retry Nightshift', callback_data: `vps_nretry:${row.id}` }]];
        else if (!themeAttempt) {
          sections.push(section('OPTIONAL NEXT STEP', [item('Panel + Wings are ready. Would you like to install the Nightshift theme?')]));
          rows = [[{ text: '🌙 Install Nightshift', callback_data: `vps_nightshift:${row.id}` },
            { text: '⏭️ Skip for now', callback_data: `vps_nightshift_skip:${row.id}` }]];
        }
        else rows = [[{ text: '🔄 Refresh', callback_data: `vps_istatus:${row.id}` }]];
      }
    } else if (retryAvailable) {
      rows.push([{ text: '🔁 Retry installation', callback_data: `vps_iretry:${row.id}` }]);
    }
    return showScreen(message, frame('INSTALL STATUS', [
      ...sections
    ]), [
      ...rows,
      [{ text: '🔄 Refresh', callback_data: `vps_istatus:${row.id}` }, { text: 'VPS details', callback_data: `vps_view:${row.id}` }], BACK_ROW
    ]);
  } catch (err) {
    return showScreen(message, note('INSTALL STATUS', 'Could not read installer progress.', safeError(err)), [BACK_ROW]);
  }
}
async function retryInstallation(message, userId, id) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('INSTALL PANEL', 'Machine not found.'), [BACK_ROW]);
  if (!config.boxdApiKey) return showScreen(message, note('INSTALL PANEL', 'BOXD_API_KEY is not configured.'), [BACK_ROW]);
  try {
    const output = await readStatus(config.boxdApiKey, row.id, row.region);
    if (!canResumeNightshiftBuild(output)) {
      return showScreen(message, note('INSTALL PANEL', 'This failure is not at the resumable Nightshift build step. Check the latest install status before retrying.'),
        [[{ text: '🟠 Install progress', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
    }
    await showScreen(message, note('INSTALL PANEL', 'Resuming the failed Nightshift build and continuing the existing Panel + Wings installation…'), []);
    await prepareAndStart(config.boxdApiKey, { id: row.id, name: row.name, region: row.region || 'fra' }, { resume: true });
    void monitorInstallation(message.chat.id, userId, row);
    return showScreen(message, note('INSTALL PANEL', 'Installation resumed from the Nightshift build step.', 'Progress updates will appear here; use Install Status at any time.'),
      [[{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
  } catch (err) {
    return showScreen(message, note('INSTALL PANEL', 'Could not resume the installer.', safeError(err)),
      [[{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
  }
}
async function startNightshiftInstallation(message, userId, id, resume = false) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('NIGHTSHIFT', 'Machine not found.'), [BACK_ROW]);
  if (!config.boxdApiKey) return showScreen(message, note('NIGHTSHIFT', 'BOXD_API_KEY is not configured.'), [BACK_ROW]);
  try {
    await showScreen(message, note('NIGHTSHIFT', resume ? 'Checking whether the failed theme build can be safely resumed…' : 'Starting the optional Nightshift theme installation…'), []);
    await prepareNightshiftAndStart(config.boxdApiKey, { id: row.id, name: row.name, region: row.region || 'fra' }, { resume });
    void monitorNightshiftInstallation(message.chat.id, userId, row);
    return showScreen(message, note('NIGHTSHIFT', resume ? 'Nightshift build resumed.' : 'Nightshift installation started.', 'Panel + Wings remain installed and running; use Install Status to follow theme progress.'),
      [[{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
  } catch (err) {
    return showScreen(message, note('NIGHTSHIFT', resume ? 'Could not resume Nightshift.' : 'Could not start Nightshift.', safeError(err)),
      [[{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
  }
}
async function skipNightshift(message, userId, id) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('NIGHTSHIFT', 'Machine not found.'), [BACK_ROW]);
  return showScreen(message, note('NIGHTSHIFT', 'Skipped for now.', 'Panel + Wings are installed and remain available. You can install Nightshift later from VPS details or Install Status.'),
    [[{ text: '🌙 Install Nightshift', callback_data: `vps_nightshift:${row.id}` }],
      [{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
}
async function requireCompletedPanel(message, userId, id, feature) {
  const row = db.getMachine(id, userId);
  if (!row) {
    await showScreen(message, note(feature, 'Machine not found.'), [BACK_ROW]);
    return false;
  }
  if (!config.boxdApiKey) {
    await showScreen(message, note(feature, 'BOXD_API_KEY is not configured.'), [BACK_ROW]);
    return false;
  }
  try {
    const output = await readStatus(config.boxdApiKey, row.id, row.region);
    if (isPanelWingsComplete(output)) return true;
    await showScreen(message, note(feature, 'Panel + Wings must report COMPLETE before this action is available.'),
      [[{ text: '🟠 Install progress', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
    return false;
  } catch (err) {
    await showScreen(message, note(feature, 'Could not verify Panel + Wings completion.', safeError(err)),
      [[{ text: '🔄 Retry', callback_data: feature === 'PUBLIC IP' ? `vps_publicip:${row.id}` : `vps_allocations:${row.id}` }], BACK_ROW]);
    return false;
  }
}
async function showDirectPublicIp(message, userId, id) {
  if (!await requireCompletedPanel(message, userId, id, 'PUBLIC IP')) return;
  return showScreen(message, note('PUBLIC IP', PUBLIC_IP_UNAVAILABLE),
    [[{ text: '📋 VPS details', callback_data: `vps_view:${id}` }], BACK_ROW]);
}
async function showAllocationAvailability(message, userId, id) {
  if (!await requireCompletedPanel(message, userId, id, 'ALLOCATIONS')) return;
  return showScreen(message, note('ASSIGN ALLOCATIONS', ALLOCATIONS_UNAVAILABLE),
    [[{ text: '📋 VPS details', callback_data: `vps_view:${id}` }], BACK_ROW]);
}
async function runMachineAction(message, userId, action, id) {
  if (action === 'vps_view') return screenMachine(message, userId, id);
  if (action === 'vps_refresh') return refreshMachine(message, userId, id);
  if (action === 'vps_publicip') return showDirectPublicIp(message, userId, id);
  if (action === 'vps_allocations') return showAllocationAvailability(message, userId, id);
  if (action === 'vps_istatus') return screenInstallStatus(message, userId, id);
  if (action === 'vps_iretry') return retryInstallation(message, userId, id);
  if (action === 'vps_nightshift') return startNightshiftInstallation(message, userId, id);
  if (action === 'vps_nretry') return startNightshiftInstallation(message, userId, id, true);
  if (action === 'vps_nightshift_skip') return skipNightshift(message, userId, id);
  if (action === 'vps_install') {
    const row = db.getMachine(id, userId);
    if (!row) return showScreen(message, note('INSTALL PANEL', 'Machine not found.'), [BACK_ROW]);
    return beginDomainSetup(message, userId, row);
  }
}

function createMachineName(userId) {
  return `tc-${String(userId).slice(-5)}-${Date.now().toString(36)}`.toLowerCase();
}
async function createMachineForUser(message, userId) {
  const draft = createDrafts.get(String(userId));
  if (!draft || draft.stage !== 'confirm') return showScreen(message, note('CREATE VPS', 'This confirmation expired; start again.'), [BACK_ROW]);
  createDrafts.delete(String(userId));
  const admin = isAdmin(userId);
  if (!admin && !db.reserveCredits(userId, config.vpsCost)) {
    return showScreen(message, note('CREATE VPS', 'Not enough coins.', 'Claim your daily reward first.'), [[{ text: '🪙 Claim Daily 10', callback_data: 'menu_claim' }], BACK_ROW]);
  }
  let boxd;
  let row;
  try {
    await showScreen(message, note('CREATE VPS', `Creating ${SIZES[draft.sizeKey].label} VPS with Boxd’s default image in ${draft.region}…`, 'Your bot coins will be refunded if provisioning reports a failure.'), []);
    const params = buildCreateOptions({ name: createMachineName(userId), sizeKey: draft.sizeKey, region: draft.region });
    boxd = await getBoxd(config.boxdApiKey, draft.region);
    const scheduled = await boxd.machines.create(params);
    if (!scheduled || !scheduled.id) throw new Error('Boxd did not return the new machine ID.');
    const ready = await boxd.machines.waitUntilReady(scheduled.id, { timeout: 90000 });
    const fresh = await boxd.machines.get(scheduled.id);
    const machine = normaliseMachine({ ...(fresh || ready || scheduled), region: (fresh || ready || scheduled).region || draft.region });
    const createdAt = machine.createdAt || new Date().toISOString();
    db.saveMachine({
      id: machine.id, telegram_id: String(userId), name: machine.name, status: machine.status,
      domain: machine.domain, url: machine.url, ssh_port: machine.sshPort,
      vcpu: machine.vcpu || SIZES[draft.sizeKey].vcpu,
      memory_bytes: machine.memoryBytes || SIZES[draft.sizeKey].memoryBytes,
      region: machine.region || draft.region, image: machine.image || null,
      public_ip: null, custom_domain: null, created_at: createdAt
    });
    row = db.getMachine(machine.id, userId);
    if (!row) throw new Error('Machine was created but could not be saved to the bot database.');
  } catch (err) {
    if (!admin) db.refundCredits(userId, config.vpsCost);
    stockCache = { at: 0, text: '' };
    return showScreen(message, note('CREATE VPS',
      admin ? 'VPS creation failed.' : `VPS creation failed; your ${config.vpsCost} coins were refunded.`,
      'If Boxd timed out, check the Boxd console before retrying in case a machine was created.', safeError(err)), [BACK_ROW]);
  } finally {
    if (boxd && boxd.close) await boxd.close().catch(() => {});
  }
  stockCache = { at: 0, text: '' };
  return showScreen(message, frame('VPS CREATED', machineSections({
    id: row.id, name: row.name, status: row.status, region: row.region,
    vcpu: row.vcpu, memoryBytes: row.memory_bytes, domain: row.domain,
      sshPort: row.ssh_port, url: row.url
  }, [line('Coins charged', admin ? '0 (Admin)' : config.vpsCost)])), [
    [{ text: '🟣 Install Panel + Wings', callback_data: cbOk('vps_install', row.id) ? `vps_install:${row.id}` : 'menu_install' }, { text: '📋 Manage VPS', callback_data: 'menu_vps' }],
    [{ text: '📲 Boxd Mobile SSH', url: 'https://app.boxd.sh/mobile' }], BACK_ROW
  ]);
}

const HELP_TEXT = frame('HELP', [
  section('COMMANDS', [
    item('/start — show the welcome image and live stats'),
    item('/create — create a VPS'), item('/myvps — manage your VPSs'),
    item('/install — install Panel + Wings'), item('/installstatus — installer progress'),
    item('/claim — claim 10 daily coins'), item('/balance — check your coins'),
    item('/status — refresh VPS status')
  ]),
  section('NOTES', [
    item('Telegram does not allow bots to choose inline keyboard button colors; this bot uses consistent emoji labels instead.'),
    item('Boxd SSH tokens are generated by Boxd from its signed-in Mobile page, not by the documented SDK.'),
    item('The VPS quota count is quota-derived and is not physical inventory.')
  ])
]);

bot.onText(/^\/start(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return bot.sendMessage(msg.chat.id, 'Please open a private chat with me.');
  register(msg);
  await sendMenu(msg.chat.id, msg.from.id);
});
bot.onText(/^\/help(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  await sendMenu(msg.chat.id, msg.from.id);
});
bot.onText(/^\/connect(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  await bot.sendMessage(msg.chat.id, 'Do not send a Boxd API key in chat. The bot owner configures the shared BOXD_API_KEY in the private .env file.');
});
bot.onText(/^\/create(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return bot.sendMessage(msg.chat.id, 'VPS creation is available in a private chat.');
  register(msg);
  await showCreateWizard(await bot.sendMessage(msg.chat.id, 'Preparing the VPS menu…'), String(msg.from.id));
});
bot.onText(/^\/myvps(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  const sent = await bot.sendMessage(msg.chat.id, 'Loading your VPS list…');
  await screenVpsList(sent, String(msg.from.id));
});
bot.onText(/^\/claim(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  const result = db.claimDaily(msg.from.id, todayEAT(), config.dailyReward);
  await bot.sendMessage(msg.chat.id, result.ok
    ? `Daily reward claimed: +${config.dailyReward} coins.\nBalance: ${result.credits} coins.`
    : `You already claimed today’s reward.\nBalance: ${result.credits} coins.`);
});
bot.onText(/^\/balance(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  const user = db.getUser(msg.from.id);
  await bot.sendMessage(msg.chat.id, isAdmin(msg.from.id)
    ? 'Admin account: VPS creation is free to you.'
    : `Your balance: ${user.credits} coins.\nVPS creation cost: ${config.vpsCost} coins.\nDaily reward: ${config.dailyReward} coins.`);
});
bot.onText(/^\/install(?:@\w+)?(?:\s+([A-Za-z0-9_-]+))?$/, async (msg, match) => {
  if (!privateOnly(msg)) return bot.sendMessage(msg.chat.id, 'Run /install in a private chat.');
  register(msg);
  const rows = db.listMachines(msg.from.id);
  const machineId = (match && match[1] || '').trim();
  const row = machineId ? db.getMachine(machineId, msg.from.id) : rows[0];
  if (!row) return bot.sendMessage(msg.chat.id, 'No owned VPS found. Create one first with /create.');
  const sent = await bot.sendMessage(msg.chat.id, 'Preparing the installation flow…');
  await beginDomainSetup(sent, String(msg.from.id), row);
});
bot.onText(/^\/installstatus(?:@\w+)?(?:\s+([A-Za-z0-9_-]+))?$/, async (msg, match) => {
  if (!privateOnly(msg)) return;
  register(msg);
  const rows = db.listMachines(msg.from.id);
  const machineId = (match && match[1] || '').trim();
  const row = machineId ? db.getMachine(machineId, msg.from.id) : rows[0];
  if (!row) return bot.sendMessage(msg.chat.id, 'No owned VPS found.');
  const sent = await bot.sendMessage(msg.chat.id, 'Reading installer status…');
  await screenInstallStatus(sent, String(msg.from.id), row.id);
});
bot.onText(/^\/status(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
  if (!privateOnly(msg)) return;
  register(msg);
  const rows = db.listMachines(msg.from.id);
  const machineId = (match && match[1] || '').trim();
  const row = machineId ? db.getMachine(machineId, msg.from.id) : rows[0];
  if (!row) return bot.sendMessage(msg.chat.id, 'Machine not found. Use /myvps to see your machine IDs.');
  const sent = await bot.sendMessage(msg.chat.id, 'Refreshing VPS status…');
  await refreshMachine(sent, String(msg.from.id), row.id);
});
bot.onText(/^\/membercheck(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg) || !isAdmin(msg.from.id)) return;
  const lines = await gate.diagnose(msg.from.id);
  await bot.sendMessage(msg.chat.id, `Membership check\n\n${lines.join('\n')}`);
});
bot.onText(/^\/adminstats(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg) || !isAdmin(msg.from.id)) return;
  register(msg);
  const stats = db.stats();
  await bot.sendMessage(msg.chat.id, `Users: ${stats.users}\nActive VPS: ${stats.activeVps}\nTotal VPS records: ${stats.totalVps}\nBot uptime: ${formatDuration(process.uptime())}`);
});

bot.on('message', async msg => {
  if (!privateOnly(msg) || !msg.text || msg.text.startsWith('/')) return;
  const userId = String(msg.from.id);
  const session = sessions.get(userId);
  if (!session || session.action !== 'custom_domain') return;
  if (!(await passGate(msg.from.id, msg.chat.id))) return;
  sessions.delete(userId);
  register(msg);
  await processDomainInput(msg, session);
});

bot.on('callback_query', async query => {
  const userId = String(query.from.id);
  const message = query.message;
  let answered = false;
  const answer = async (text, alert = false) => {
    if (answered) return;
    answered = true;
    try { await bot.answerCallbackQuery(query.id, text ? { text, ...(alert ? { show_alert: true } : {}) } : {}); } catch {}
  };
  if (!message || !message.chat || message.chat.type !== 'private') return answer('Use the bot in a private chat.');
  db.registerUser(query.from.id, query.from.username || null);
  const data = String(query.data || '');
  const split = data.indexOf(':');
  const arg = split >= 0 ? data.slice(split + 1) : '';
  try {
    if (data === 'verify_join') {
      const verdict = await gate.check(userId, { force: true });
      if (verdict.ok) {
        await answer('✅ Verified. Welcome!');
        try { await bot.deleteMessage(message.chat.id, message.message_id); } catch {}
        return sendMenu(message.chat.id, userId);
      }
      await answer('You have not joined everything yet.', true);
      return showScreen(message, gateText(verdict.results), gateRows());
    }
    const passed = await gate.check(userId);
    if (!passed.ok) {
      await answer('Join the required chats to use the bot.', true);
      return showScreen(message, gateText(passed.results), gateRows());
    }
    if (data === 'menu_home') {
      await answer();
      sessions.delete(userId);
      createDrafts.delete(userId);
      pendingInstalls.delete(userId);
      domainDrafts.delete(userId);
      return restoreMainMenu(message, userId, {
        webAppUrl: config.webAppUrl, isAdmin, startText, showScreen
      });
    }
    if (data === 'menu_stats') { await answer(); return showScreen(message, await statsText(userId), [[{ text: '🔄 Refresh stats', callback_data: 'menu_stats' }], BACK_ROW]); }
    if (data === 'menu_create') { await answer(); return showCreateWizard(message, userId); }
    if (data === 'menu_vps') { await answer(); return screenVpsList(message, userId); }
    if (data === 'menu_install') { await answer(); return machinePicker(message, userId, 'vps_install', 'Choose the VPS for Panel + Wings installation:'); }
    if (data === 'menu_installstatus') { await answer(); return machinePicker(message, userId, 'vps_istatus', 'Choose the VPS to check:'); }
    if (data === 'menu_claim') {
      await answer();
      const result = db.claimDaily(userId, todayEAT(), config.dailyReward);
      return showScreen(message, frame('DAILY COINS', [section(result.ok ? 'CLAIMED' : 'ALREADY CLAIMED', [
        item(result.ok ? `+${config.dailyReward} coins added.` : 'You already claimed today’s reward.'),
        line('Balance', `${result.credits} coins`)
      ])]), [[{ text: '💰 Balance', callback_data: 'menu_balance' }], BACK_ROW]);
    }
    if (data === 'menu_balance') {
      await answer();
      const user = db.getUser(userId);
      return showScreen(message, frame('COIN BALANCE', [section('ACCOUNT', isAdmin(userId)
        ? [item('Admin account: VPS creation is free to you.')]
        : [line('Balance', `${user ? user.credits : 0} coins`), line('VPS cost', `${config.vpsCost} coins`), line('Daily claim', `${config.dailyReward} coins`)
        ])]), [[{ text: '🪙 Claim Daily 10', callback_data: 'menu_claim' }], BACK_ROW]);
    }
    if (data === 'menu_help') { await answer(); return showScreen(message, HELP_TEXT, [BACK_ROW]); }
    if (data === 'menu_admin') {
      if (!isAdmin(userId)) return answer('Admins only.');
      await answer();
      const stats = db.stats();
      return showScreen(message, frame('ADMIN STATS', [section('OVERVIEW', [
        line('Users', stats.users), line('Active VPS', stats.activeVps),
        line('Total VPS records', stats.totalVps), line('Bot uptime', esc(formatDuration(process.uptime())))
      ])]), [[{ text: '🔄 Refresh', callback_data: 'menu_admin' }], BACK_ROW]);
    }
    if (data === 'create_cancel') { createDrafts.delete(userId); await answer('Cancelled.'); return showScreen(message, note('CREATE VPS', 'VPS creation cancelled.'), [BACK_ROW]); }
    if (data.startsWith('create_size:')) {
      const draft = createDrafts.get(userId);
      if (!draft || !SIZES[arg]) { await answer('Start the create flow again.'); return showCreateWizard(message, userId); }
      draft.sizeKey = arg;
      await answer();
      return showRegionPicker(message, userId);
    }
    if (data.startsWith('create_region:')) {
      const draft = createDrafts.get(userId);
      if (!draft || !(draft.regions || []).some(region => region.id === arg)) { await answer('Choose a region from the current list.'); return showRegionPicker(message, userId); }
      draft.region = arg;
      await answer();
      return showCreateConfirmation(message, userId);
    }
    if (data.startsWith('create_os:')) {
      const draft = createDrafts.get(userId);
      await answer('Boxd default is selected automatically.');
      if (!draft || !draft.sizeKey || !draft.region) return showCreateWizard(message, userId);
      return showCreateConfirmation(message, userId);
    }
    if (data === 'create_confirm') {
      await answer('Creating VPS…');
      return createMachineForUser(message, userId);
    }
    if (data === 'domain_cancel') { domainDrafts.delete(userId); await answer('Cancelled.'); return showScreen(message, note('CUSTOM DOMAIN', 'Domain setup cancelled.'), [BACK_ROW]); }
    if (data.startsWith('domain_skip:')) {
      const row = db.getMachine(arg, userId);
      if (!row) { await answer('Machine not found.'); return; }
      sessions.delete(userId); domainDrafts.delete(userId);
      const prompt = installPrompt(userId, row);
      await answer();
      return showScreen(message, prompt.text, prompt.rows);
    }
    if (data === 'domain_verify') { await answer('Checking DNS…'); return verifyAndBindDomain(message, userId); }
    if (data.startsWith('domain_status:')) {
      const row = db.getMachine(arg, userId);
      if (!row) { await answer('Machine not found.'); return; }
      await answer();
      return checkCustomDomainStatus(message, userId, row);
    }
    if (data.startsWith('install_begin:')) {
      const row = db.getMachine(arg, userId);
      if (!row) { await answer('Machine not found.'); return; }
      const prompt = installPrompt(userId, row);
      await answer();
      return showScreen(message, prompt.text, prompt.rows);
    }
    if (data.startsWith('vps_view:') || data.startsWith('vps_refresh:') || data.startsWith('vps_publicip:') || data.startsWith('vps_allocations:') || data.startsWith('vps_install:') || data.startsWith('vps_istatus:') || data.startsWith('vps_iretry:') || data.startsWith('vps_nightshift:') || data.startsWith('vps_nretry:') || data.startsWith('vps_nightshift_skip:')) {
      await answer();
      return runMachineAction(message, userId, data.slice(0, split), arg);
    }
    if (data === 'install_cancel') {
      pendingInstalls.delete(userId);
      await answer('Cancelled.');
      return showScreen(message, note('INSTALL PANEL', 'Panel + Wings installation cancelled.'), [BACK_ROW]);
    }
    if (data === 'install_confirm') {
      const machineId = pendingInstalls.get(userId);
      pendingInstalls.delete(userId);
      const row = machineId && db.getMachine(machineId, userId);
      if (!row) { await answer('Request expired.'); return showScreen(message, note('INSTALL PANEL', 'Installation request expired. Start it again from the menu.'), [BACK_ROW]); }
      await answer('Starting installer…');
      await showScreen(message, note('INSTALL PANEL', 'Preparing Boxd proxies and launching the installer…'), []);
      try {
        const details = await prepareAndStart(config.boxdApiKey, { id: row.id, name: row.name, region: row.region || 'fra' });
        await bot.sendMessage(message.chat.id, frame('INSTALLER STARTED', [
          section('PANEL', [line('Panel URL', `<a href="https://${esc(details.panelDomain)}">https://${esc(details.panelDomain)}</a>`), line('Wings URL', `https://${esc(details.wingsDomain)}:443`), line('SFTP public port', esc(details.sftpPublicPort))]),
          section('PANEL ADMIN', [line('Email', `<code>${esc(details.adminEmail)}</code>`), line('Username', `<code>${esc(details.adminUsername)}</code>`), line('Password', `<code>${esc(details.adminPassword)}</code>`)]),
          section('NOTES', [item('Keep the Panel credentials private.'), item('Wait for the installation progress to reach COMPLETE before logging in.'), item('The installer uses Boxd’s canonical machine hostname for the primary Panel URL.')])
        ]), { parse_mode: 'HTML' });
        void monitorInstallation(message.chat.id, userId, row);
        return showScreen(message, note('INSTALL PANEL', 'Installation is in progress.', 'Progress updates will appear here; use Install Status at any time.'), [[{ text: '🟠 Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
      } catch (err) {
        return showScreen(message, note('INSTALL PANEL', 'Could not start the installer.', safeError(err)), [BACK_ROW]);
      }
    }
    await answer();
  } catch (err) {
    console.error('[callback error]', safeError(err));
    await answer('Something went wrong.');
  }
});

bot.on('polling_error', err => console.error('[Telegram polling error]', safeError(err)));
console.log(`[${config.botName}] running. Users are charged bot coins; Boxd usage is billed to the configured Boxd account.`);
